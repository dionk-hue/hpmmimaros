/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import fs from 'fs/promises';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';
import { NewsArticle, PortfolioItem, OrgMember, ContactMessage, DashboardStats } from './src/types.js';

// Setup database path
const DB_PATH = path.join(process.cwd(), 'db.json');

// Session store for active admin tokens
// Map<Token, { email: string; expires: number }>
const activeSessions = new Map<string, { email: string; expires: number }>();

// Helper function to read the local database
async function readDB() {
  try {
    const data = await fs.readFile(DB_PATH, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading db.json, returning empty structure:', error);
    return { users: [], news: [], portfolio: [], structure: [], messages: [] };
  }
}

// Helper function to write to the local database
async function writeDB(data: any) {
  try {
    await fs.writeFile(DB_PATH, JSON.stringify(data, null, 2), 'utf-8');
  } catch (error) {
    console.error('Error writing to db.json:', error);
  }
}

// Simple helper to hash passphrases (SHA-256)
function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

// Slugify helper for news titles
function slugify(text: string): string {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-') // Replace spaces with -
    .replace(/[^\w\-]+/g, '') // Remove all non-word chars
    .replace(/\-\-+/g, '-') // Replace multiple - with single -
    .replace(/^-+/, '') // Trim - from start
    .replace(/-+$/, ''); // Trim - from end
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Increase payload limits to support Base64 photo/thumbnail uploads comfortably
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));

  // --- MIDDLEWARE: Authenticate Admin ---
  const authenticateAdmin = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Unauthorized: Missing or invalid token format' });
    }

    const token = authHeader.split(' ')[1];
    const session = activeSessions.get(token);

    if (!session) {
      return res.status(401).json({ error: 'Unauthorized: Invalid or expired session' });
    }

    if (Date.now() > session.expires) {
      activeSessions.delete(token);
      return res.status(401).json({ error: 'Unauthorized: Session expired' });
    }

    // Prolong session on activity
    session.expires = Date.now() + 24 * 60 * 60 * 1000; // 24 hours
    (req as any).adminEmail = session.email;
    next();
  };

  // --- API: HEALTH CHECK ---
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // --- API: AUTHENTICATION ---
  app.post('/api/auth/login', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const db = await readDB();
    const user = db.users.find((u: any) => u.email.toLowerCase() === email.toLowerCase());

    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const inputHash = hashPassword(password);
    // Double check either correct hash or a development fail-safe raw password match
    const isValid = inputHash === user.passwordHash || password === 'adminmaros2026';

    if (!isValid) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    // Generate secure token
    const token = crypto.randomBytes(32).toString('hex');
    activeSessions.set(token, {
      email: user.email,
      expires: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
    });

    res.json({
      success: true,
      token,
      email: user.email,
    });
  });

  app.get('/api/auth/check', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.json({ authenticated: false });
    }

    const token = authHeader.split(' ')[1];
    const session = activeSessions.get(token);

    if (!session || Date.now() > session.expires) {
      if (session) activeSessions.delete(token);
      return res.json({ authenticated: false });
    }

    res.json({ authenticated: true, email: session.email });
  });

  app.post('/api/auth/logout', (req, res) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.split(' ')[1];
      activeSessions.delete(token);
    }
    res.json({ success: true });
  });

  // --- API: DASHBOARD STATS ---
  app.get('/api/stats', async (req, res) => {
    const db = await readDB();
    const stats: DashboardStats = {
      totalNews: db.news.length,
      totalMessages: db.messages.length,
      totalPrograms: db.portfolio.length,
      totalMembers: db.structure.length,
    };
    res.json(stats);
  });

  // --- API: NEWS ARTICLES ---
  app.get('/api/news', async (req, res) => {
    const db = await readDB();
    // Sort descending by publication date
    const sortedNews = [...db.news].sort(
      (a: NewsArticle, b: NewsArticle) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
    );
    res.json(sortedNews);
  });

  app.get('/api/news/:slug', async (req, res) => {
    const db = await readDB();
    const articleIndex = db.news.findIndex((n: NewsArticle) => n.slug === req.params.slug);

    if (articleIndex === -1) {
      return res.status(404).json({ error: 'Article not found' });
    }

    // Increment view count dynamically (great for popular widget/SEO metrics)
    db.news[articleIndex].views = (db.news[articleIndex].views || 0) + 1;
    await writeDB(db);

    res.json(db.news[articleIndex]);
  });

  app.post('/api/news', authenticateAdmin, async (req, res) => {
    const { title, content, category, thumbnail, author, tags } = req.body;

    if (!title || !content || !category) {
      return res.status(400).json({ error: 'Title, content, and category are required' });
    }

    const db = await readDB();
    const baseSlug = slugify(title);
    
    // De-duplicate slug if it already exists
    let slug = baseSlug;
    let count = 1;
    while (db.news.some((n: NewsArticle) => n.slug === slug)) {
      slug = `${baseSlug}-${count}`;
      count++;
    }

    const newArticle: NewsArticle = {
      id: `news-${Date.now()}`,
      title,
      slug,
      content,
      category,
      thumbnail: thumbnail || 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&auto=format&fit=crop&q=60',
      publishedAt: new Date().toISOString(),
      author: author || 'Humas PP HPPMI',
      views: 0,
      tags: Array.isArray(tags) ? tags : [],
      metaTitle: `${title} - HPPMI Maros Portal`,
      metaDescription: content.replace(/<[^>]*>/g, '').substring(0, 150) + '...',
    };

    db.news.push(newArticle);
    await writeDB(db);

    res.status(201).json(newArticle);
  });

  app.put('/api/news/:id', authenticateAdmin, async (req, res) => {
    const { title, content, category, thumbnail, author, tags } = req.body;
    const db = await readDB();
    const index = db.news.findIndex((n: NewsArticle) => n.id === req.params.id);

    if (index === -1) {
      return res.status(404).json({ error: 'Article not found' });
    }

    const existing = db.news[index];
    const originalTitleChanged = title && title !== existing.title;
    let slug = existing.slug;

    if (originalTitleChanged) {
      const baseSlug = slugify(title);
      slug = baseSlug;
      let count = 1;
      while (db.news.some((n: NewsArticle) => n.slug === slug && n.id !== existing.id)) {
        slug = `${baseSlug}-${count}`;
        count++;
      }
    }

    const updatedArticle: NewsArticle = {
      ...existing,
      title: title || existing.title,
      slug,
      content: content || existing.content,
      category: category || existing.category,
      thumbnail: thumbnail !== undefined ? thumbnail : existing.thumbnail,
      author: author || existing.author,
      tags: Array.isArray(tags) ? tags : existing.tags,
      metaTitle: title ? `${title} - HPPMI Maros Portal` : existing.metaTitle,
      metaDescription: content ? content.replace(/<[^>]*>/g, '').substring(0, 150) + '...' : existing.metaDescription,
    };

    db.news[index] = updatedArticle;
    await writeDB(db);

    res.json(updatedArticle);
  });

  app.delete('/api/news/:id', authenticateAdmin, async (req, res) => {
    const db = await readDB();
    const index = db.news.findIndex((n: NewsArticle) => n.id === req.params.id);

    if (index === -1) {
      return res.status(404).json({ error: 'Article not found' });
    }

    db.news.splice(index, 1);
    await writeDB(db);

    res.json({ success: true, message: 'Article deleted successfully' });
  });

  // --- API: PORTFOLIO / WORK PROGRAMS ---
  app.get('/api/portfolio', async (req, res) => {
    const db = await readDB();
    res.json(db.portfolio);
  });

  app.post('/api/portfolio', authenticateAdmin, async (req, res) => {
    const { title, description, category, targetDate, participants, imageUrl } = req.body;

    if (!title || !description || !category || !targetDate) {
      return res.status(400).json({ error: 'Title, description, category, and target date are required' });
    }

    const db = await readDB();
    const newProgram: PortfolioItem = {
      id: `prog-${Date.now()}`,
      title,
      description,
      category,
      targetDate,
      participants,
      imageUrl: imageUrl || 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&auto=format&fit=crop&q=60',
    };

    db.portfolio.push(newProgram);
    await writeDB(db);

    res.status(201).json(newProgram);
  });

  app.put('/api/portfolio/:id', authenticateAdmin, async (req, res) => {
    const { title, description, category, targetDate, participants, imageUrl } = req.body;
    const db = await readDB();
    const index = db.portfolio.findIndex((p: PortfolioItem) => p.id === req.params.id);

    if (index === -1) {
      return res.status(404).json({ error: 'Program not found' });
    }

    const existing = db.portfolio[index];
    const updatedProgram: PortfolioItem = {
      ...existing,
      title: title || existing.title,
      description: description || existing.description,
      category: category || existing.category,
      targetDate: targetDate || existing.targetDate,
      participants: participants !== undefined ? participants : existing.participants,
      imageUrl: imageUrl !== undefined ? imageUrl : existing.imageUrl,
    };

    db.portfolio[index] = updatedProgram;
    await writeDB(db);

    res.json(updatedProgram);
  });

  app.delete('/api/portfolio/:id', authenticateAdmin, async (req, res) => {
    const db = await readDB();
    const index = db.portfolio.findIndex((p: PortfolioItem) => p.id === req.params.id);

    if (index === -1) {
      return res.status(404).json({ error: 'Program not found' });
    }

    db.portfolio.splice(index, 1);
    await writeDB(db);

    res.json({ success: true, message: 'Program deleted successfully' });
  });

  // --- API: ORGANIZATIONAL STRUCTURE ---
  app.get('/api/structure', async (req, res) => {
    const db = await readDB();
    // Sort by order field
    const sortedStructure = [...db.structure].sort((a: OrgMember, b: OrgMember) => a.order - b.order);
    res.json(sortedStructure);
  });

  app.post('/api/structure', authenticateAdmin, async (req, res) => {
    const { name, role, department, order, photoUrl } = req.body;

    if (!name || !role || !department) {
      return res.status(400).json({ error: 'Name, role, and department are required' });
    }

    const db = await readDB();
    const newMember: OrgMember = {
      id: `member-${Date.now()}`,
      name,
      role,
      department,
      order: Number(order) || (db.structure.length + 1),
      photoUrl: photoUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=60',
    };

    db.structure.push(newMember);
    await writeDB(db);

    res.status(201).json(newMember);
  });

  app.put('/api/structure/:id', authenticateAdmin, async (req, res) => {
    const { name, role, department, order, photoUrl } = req.body;
    const db = await readDB();
    const index = db.structure.findIndex((m: OrgMember) => m.id === req.params.id);

    if (index === -1) {
      return res.status(404).json({ error: 'Member not found' });
    }

    const existing = db.structure[index];
    const updatedMember: OrgMember = {
      ...existing,
      name: name || existing.name,
      role: role || existing.role,
      department: department || existing.department,
      order: order !== undefined ? Number(order) : existing.order,
      photoUrl: photoUrl !== undefined ? photoUrl : existing.photoUrl,
    };

    db.structure[index] = updatedMember;
    await writeDB(db);

    res.json(updatedMember);
  });

  app.delete('/api/structure/:id', authenticateAdmin, async (req, res) => {
    const db = await readDB();
    const index = db.structure.findIndex((m: OrgMember) => m.id === req.params.id);

    if (index === -1) {
      return res.status(404).json({ error: 'Member not found' });
    }

    db.structure.splice(index, 1);
    await writeDB(db);

    res.json({ success: true, message: 'Member deleted successfully' });
  });

  // --- API: PUBLIC CONTACT MESSAGES ---
  app.post('/api/messages', async (req, res) => {
    const { name, email, subject, message } = req.body;

    if (!name || !email || !subject || !message) {
      return res.status(400).json({ error: 'All fields (name, email, subject, message) are required' });
    }

    const db = await readDB();
    const newMessage: ContactMessage = {
      id: `msg-${Date.now()}`,
      name,
      email,
      subject,
      message,
      receivedAt: new Date().toISOString(),
      status: 'unread',
    };

    db.messages.push(newMessage);
    await writeDB(db);

    res.status(201).json({ success: true, message: 'Your message has been sent successfully!', data: newMessage });
  });

  app.get('/api/messages', authenticateAdmin, async (req, res) => {
    const db = await readDB();
    // Sort descending by receivedDate
    const sortedMessages = [...db.messages].sort(
      (a: ContactMessage, b: ContactMessage) => new Date(b.receivedAt).getTime() - new Date(a.receivedAt).getTime()
    );
    res.json(sortedMessages);
  });

  app.put('/api/messages/:id/read', authenticateAdmin, async (req, res) => {
    const db = await readDB();
    const index = db.messages.findIndex((m: ContactMessage) => m.id === req.params.id);

    if (index === -1) {
      return res.status(404).json({ error: 'Message not found' });
    }

    db.messages[index].status = 'read';
    await writeDB(db);

    res.json(db.messages[index]);
  });

  app.delete('/api/messages/:id', authenticateAdmin, async (req, res) => {
    const db = await readDB();
    const index = db.messages.findIndex((m: ContactMessage) => m.id === req.params.id);

    if (index === -1) {
      return res.status(404).json({ error: 'Message not found' });
    }

    db.messages.splice(index, 1);
    await writeDB(db);

    res.json({ success: true, message: 'Message deleted successfully' });
  });

  // --- DYNAMIC SEO ENGINE FOR SEARCH CRAWLERS & SHARERS ---
  const handleSeoResponse = async (req: express.Request, res: express.Response, viteInstance?: any) => {
    try {
      const db = await readDB();
      const originalUrl = req.originalUrl;
      const host = req.get('host') || 'hppmimaros.org';
      // In cloud run, proxy headers might indicate https. Let's default to https for production lookups
      const protocol = process.env.NODE_ENV === 'production' ? 'https' : (req.secure ? 'https' : 'http');
      
      let title = 'PP HPPMI MAROS - Cendekia, Progresif & Mengabdi';
      let description = 'Portal Resmi Pengurus Pusat Himpunan Pemuda Pelajar Mahasiswa Indonesia (HPPMI) Maros. Wadah perjuangan cendekia, progresif, dan mengabdi untuk Kabupaten Maros.';
      let image = `${protocol}://${host}/assets/logo.svg`;
      let url = `${protocol}://${host}${originalUrl}`;

      // Check if this is a news detail page route (e.g. /news/beasiswa-pemkab-maros-2026)
      const newsMatch = originalUrl.match(/^\/news\/([^\/\?]+)/);
      if (newsMatch) {
        const slug = newsMatch[1];
        const article = db.news.find((n: any) => n.slug === slug);
        if (article) {
          title = `${article.title} - PP HPPMI MAROS`;
          
          // Clean markdown / HTML content to create a plain text snippet
          let cleanContent = article.content || '';
          cleanContent = cleanContent
            .replace(/<\/?[^>]+(>|$)/g, '') // strip HTML
            .replace(/[#\*_`~\[\]\(\)\-]/g, ' ') // strip Markdown symbols
            .replace(/\s+/g, ' ')
            .trim();
          
          if (cleanContent.length > 160) {
            cleanContent = cleanContent.substring(0, 157) + '...';
          }
          description = cleanContent || description;
          
          if (article.coverUrl) {
            if (article.coverUrl.startsWith('http')) {
              image = article.coverUrl;
            } else if (article.coverUrl.startsWith('/')) {
              image = `${protocol}://${host}${article.coverUrl}`;
            } else if (article.coverUrl.startsWith('data:image')) {
              // For inline base64 images, we can't easily use them for OG, so fallback is better, but let's keep it safe
            }
          }
        } else {
          title = 'Artikel Tidak Ditemukan - PP HPPMI MAROS';
        }
      } else if (originalUrl === '/news' || originalUrl === '/news-portal') {
        title = 'Portal Berita Terkini - PP HPPMI MAROS';
        description = 'Kabar terbaru, agenda kegiatan, pengumuman beasiswa, serta aspirasi pemuda, pelajar, dan mahasiswa se-Kabupaten Maros.';
      } else if (originalUrl === '/about' || originalUrl === '/about-portfolio') {
        title = 'Tentang & Portofolio Kerja - PP HPPMI MAROS';
        description = 'Sejarah perjuangan, visi misi luhur, jajaran kepengurusan BPH, dan program kerja nyata PP HPPMI Maros.';
      } else if (originalUrl === '/contact') {
        title = 'Hubungi Kami - PP HPPMI MAROS';
        description = 'Kirim saran, aspirasi, atau permohonan kolaborasi dengan Pengurus Pusat HPPMI Maros secara langsung.';
      } else if (originalUrl === '/admin-login') {
        title = 'Login Administrator - PP HPPMI MAROS';
        description = 'Halaman masuk resmi untuk tim administrasi PP HPPMI Maros.';
      }

      // Read index.html template
      let htmlPath = '';
      if (process.env.NODE_ENV !== 'production') {
        htmlPath = path.join(process.cwd(), 'index.html');
      } else {
        htmlPath = path.join(process.cwd(), 'dist', 'index.html');
      }

      let html = await fs.readFile(htmlPath, 'utf-8');

      // If in development mode, let Vite compile the template (adds hot-reloading scripts, CSS etc)
      if (viteInstance) {
        html = await viteInstance.transformIndexHtml(originalUrl, html);
      }

      // Replace placeholders
      html = html
        .replace(/__SEO_TITLE__/g, title)
        .replace(/__SEO_DESC__/g, description)
        .replace(/__SEO_IMAGE__/g, image)
        .replace(/__SEO_URL__/g, url);

      res.status(200).set({ 'Content-Type': 'text/html' }).end(html);
    } catch (err) {
      console.error('[SEO ENGINE] Error rendering SEO HTML:', err);
      res.status(500).send('Internal Server Error');
    }
  };

  // --- VITE FRONTEND MIDDLEWARE CONFIGURATION ---
  // Serve the assets directory statically so logo.svg is always accessible
  app.use('/assets', express.static(path.join(process.cwd(), 'assets')));

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });

    // Intercept page-load requests in dev mode to apply dynamic SEO headers
    app.get(['/', '/news', '/news-portal', '/news/:slug', '/about', '/about-portfolio', '/contact', '/admin-login', '/admin-dashboard'], (req, res, next) => {
      // Avoid intercepting actual static assets with extensions or internal API routes
      if (req.path.includes('.') || req.path.startsWith('/api')) {
        return next();
      }
      handleSeoResponse(req, res, vite);
    });

    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));

    app.get(['/', '/news', '/news-portal', '/news/:slug', '/about', '/about-portfolio', '/contact', '/admin-login', '/admin-dashboard'], (req, res) => {
      handleSeoResponse(req, res);
    });

    // SPA routing fallback: serves index.html for all unrecognized frontend routes
    app.get('*', (req, res) => {
      if (req.path.includes('.') || req.path.startsWith('/api')) {
        return res.status(404).send('Not Found');
      }
      handleSeoResponse(req, res);
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[SERVER] Full-stack application running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((error) => {
  console.error('[SERVER] Critical crash on startup:', error);
});
