/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface NewsArticle {
  id: string;
  title: string;
  slug: string;
  content: string; // supports HTML or markdown (we'll implement formatting)
  category: 'Pendidikan' | 'Sosial' | 'internal HPPMI' | 'Opini';
  thumbnail: string; // Base64 data URL or stock image URL
  publishedAt: string; // ISO date
  author: string;
  views: number;
  tags: string[];
  metaTitle: string;
  metaDescription: string;
}

export interface PortfolioItem {
  id: string;
  title: string;
  description: string;
  category: 'Past' | 'Ongoing' | 'Upcoming';
  targetDate: string; // Date or month string
  participants?: string; // e.g. "50+ Cadres"
  imageUrl: string; // Base64 or stock URL
}

export interface OrgMember {
  id: string;
  name: string;
  role: string;
  department: string; // 'BPH' (Badan Pengurus Harian), 'Pendidikan', 'Sosial', 'Humas', etc.
  order: number; // for rendering sorting
  photoUrl: string; // Base64 or stock URL
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  receivedAt: string; // ISO date
  status: 'unread' | 'read';
}

export interface DashboardStats {
  totalNews: number;
  totalMessages: number;
  totalPrograms: number;
  totalMembers: number;
}
