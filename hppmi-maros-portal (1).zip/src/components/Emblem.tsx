/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface EmblemProps {
  className?: string;
  size?: number;
}

export default function Emblem({ className = '', size = 40 }: EmblemProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`${className} select-none`}
    >
      {/* Outer Golden Border */}
      <circle cx="50" cy="50" r="48" fill="#0B5345" stroke="#F1C40F" strokeWidth="3" />
      
      {/* Inner Green Starburst Accent */}
      <circle cx="50" cy="50" r="42" fill="#0E6251" stroke="#F1C40F" strokeWidth="1" strokeDasharray="3 3" />
      
      {/* Shield/Emblem Center */}
      <path
        d="M50 18 C65 18 72 26 72 45 C72 65 58 78 50 82 C42 78 28 65 28 45 C28 26 35 18 50 18 Z"
        fill="#117A65"
        stroke="#F1C40F"
        strokeWidth="2"
      />

      {/* Book (Symbol of Student & Scholar Education) */}
      <path
        d="M38 52 C44 50 50 53 50 53 C50 53 56 50 62 52 V38 C56 36 50 39 50 39 C50 39 44 36 38 38 Z"
        fill="#FFFFFF"
        stroke="#0B5345"
        strokeWidth="1.5"
        strokeLinejoin="round"
      />
      <line x1="50" y1="39" x2="50" y2="53" stroke="#0B5345" strokeWidth="1.5" />

      {/* Star of Unity */}
      <path
        d="M50 24 L52.5 30 L58.5 30.5 L54 34.5 L55.5 40.5 L50 37.5 L44.5 40.5 L46 34.5 L41.5 30.5 L47.5 30 Z"
        fill="#F1C40F"
      />

      {/* Rice & Cotton representation (Kemakmuran) */}
      <path d="M32 58 C34 66 42 72 50 72" stroke="#F1C40F" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M68 58 C66 66 58 72 50 72" stroke="#F1C40F" strokeWidth="1.5" strokeLinecap="round" />

      {/* Subtle Text Ring */}
      <path id="textPath" d="M 12 50 A 38 38 0 1 1 88 50" fill="none" />
    </svg>
  );
}
