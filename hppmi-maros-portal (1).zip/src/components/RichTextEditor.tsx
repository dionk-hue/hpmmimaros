/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from 'react';
import { Bold, Italic, Heading3, List, Quote, Link as LinkIcon, Eye, Code } from 'lucide-react';

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export default function RichTextEditor({ value, onChange, placeholder = 'Tulis konten berita di sini...' }: RichTextEditorProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [activeTab, setActiveTab] = useState<'edit' | 'preview'>('edit');

  const insertTag = (tagOpen: string, tagClose: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    const selected = text.substring(start, end);

    const replacement = tagOpen + (selected || 'teks') + tagClose;
    const newValue = text.substring(0, start) + replacement + text.substring(end);

    onChange(newValue);

    // Re-focus and reset selection
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + tagOpen.length, start + tagOpen.length + (selected || 'teks').length);
    }, 50);
  };

  const handleBold = () => insertTag('<strong>', '</strong>');
  const handleItalic = () => insertTag('<em>', '</em>');
  const handleHeading = () => insertTag('<h5>', '</h5>');
  const handleQuote = () => insertTag('<blockquote>', '</blockquote>');
  const handleBullet = () => insertTag('<ul>\n  <li>', '</li>\n</ul>');
  const handleLink = () => {
    const url = prompt('Masukkan URL Link:', 'https://');
    if (url) {
      insertTag(`<a href="${url}" target="_blank" class="text-amber-500 hover:underline">`, '</a>');
    }
  };

  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden bg-white shadow-sm">
      {/* Editor Header */}
      <div className="flex justify-between items-center bg-gray-50 border-b border-gray-200 px-4 py-2">
        <div className="flex items-center space-x-1">
          {activeTab === 'edit' && (
            <>
              <button
                type="button"
                onClick={handleBold}
                className="p-1.5 hover:bg-gray-200 rounded text-gray-700 transition"
                title="Tebal (Bold)"
              >
                <Bold size={16} />
              </button>
              <button
                type="button"
                onClick={handleItalic}
                className="p-1.5 hover:bg-gray-200 rounded text-gray-700 transition"
                title="Miring (Italic)"
              >
                <Italic size={16} />
              </button>
              <button
                type="button"
                onClick={handleHeading}
                className="p-1.5 hover:bg-gray-200 rounded text-gray-700 transition"
                title="Judul Kecil (H5)"
              >
                <Heading3 size={16} />
              </button>
              <button
                type="button"
                onClick={handleQuote}
                className="p-1.5 hover:bg-gray-200 rounded text-gray-700 transition"
                title="Kutipan (Blockquote)"
              >
                <Quote size={16} />
              </button>
              <button
                type="button"
                onClick={handleBullet}
                className="p-1.5 hover:bg-gray-200 rounded text-gray-700 transition"
                title="Daftar Bulatan (Bullet List)"
              >
                <List size={16} />
              </button>
              <button
                type="button"
                onClick={handleLink}
                className="p-1.5 hover:bg-gray-200 rounded text-gray-700 transition"
                title="Tautkan Link"
              >
                <LinkIcon size={16} />
              </button>
              <div className="h-4 w-[1px] bg-gray-300 mx-1" />
            </>
          )}
        </div>

        {/* Tab Selector */}
        <div className="flex bg-gray-200 p-0.5 rounded-lg text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('edit')}
            className={`flex items-center space-x-1 px-3 py-1 rounded-md transition ${
              activeTab === 'edit' ? 'bg-white shadow-sm font-semibold text-gray-800' : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Code size={12} />
            <span>Tulis</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('preview')}
            className={`flex items-center space-x-1 px-3 py-1 rounded-md transition ${
              activeTab === 'preview' ? 'bg-white shadow-sm font-semibold text-gray-800' : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Eye size={12} />
            <span>Pratinjau</span>
          </button>
        </div>
      </div>

      {/* Editor Body */}
      {activeTab === 'edit' ? (
        <textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="w-full h-80 px-4 py-3 text-sm focus:outline-none focus:ring-0 font-mono text-gray-800 resize-y"
        />
      ) : (
        <div className="px-4 py-3 h-80 overflow-y-auto bg-gray-50 border-t-0">
          {value.trim() ? (
            <div
              className="prose prose-emerald prose-sm max-w-none text-gray-800"
              dangerouslySetInnerHTML={{ __html: value }}
            />
          ) : (
            <p className="text-gray-400 italic text-sm">Belum ada konten untuk ditampilkan.</p>
          )}
        </div>
      )}
    </div>
  );
}
