/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Mail, Phone, MapPin, Instagram, Facebook, Youtube, Globe } from 'lucide-react';
import Emblem from './Emblem.tsx';

interface FooterProps {
  onNavigate: (page: string) => void;
  activePage: string;
}

export default function Footer({ onNavigate, activePage }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#052821] text-gray-300 border-t border-emerald-900/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Brand Column */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center space-x-3">
              <Emblem size={50} />
              <div>
                <h4 className="font-display font-bold text-lg text-white leading-tight">
                  PP HPPMI MAROS
                </h4>
                <p className="text-xs text-amber-400 font-mono tracking-wider uppercase">
                  Himpunan Pemuda Pelajar Mahasiswa Indonesia
                </p>
              </div>
            </div>
            <p className="text-sm text-gray-400 max-w-sm leading-relaxed">
              Wadah perjuangan, pembinaan, dan penyaluran aspirasi pemuda, pelajar, dan mahasiswa asal Kabupaten Maros. Berkomitmen melahirkan insan akademis, pencipta, pengabdi yang bernafaskan Islam, dan bertanggung jawab atas terwujudnya masyarakat adil makmur.
            </p>
            <div className="flex space-x-4 pt-2">
              <a href="#" className="p-2 bg-[#0b3d33] hover:bg-[#135d4e] rounded-full text-amber-400 transition-colors duration-200">
                <Instagram size={18} />
              </a>
              <a href="#" className="p-2 bg-[#0b3d33] hover:bg-[#135d4e] rounded-full text-amber-400 transition-colors duration-200">
                <Facebook size={18} />
              </a>
              <a href="#" className="p-2 bg-[#0b3d33] hover:bg-[#135d4e] rounded-full text-amber-400 transition-colors duration-200">
                <Youtube size={18} />
              </a>
              <a href="#" className="p-2 bg-[#0b3d33] hover:bg-[#135d4e] rounded-full text-amber-400 transition-colors duration-200">
                <Globe size={18} />
              </a>
            </div>
          </div>

          {/* Quick Links Column */}
          <div className="space-y-4">
            <h4 className="font-display font-semibold text-white uppercase tracking-wider text-sm border-b border-emerald-950 pb-2">
              Navigasi Cepat
            </h4>
            <ul className="space-y-2.5 text-sm">
              {[
                { label: 'Beranda', id: 'home' },
                { label: 'Tentang & Program', id: 'about' },
                { label: 'Portal Berita', id: 'news' },
                { label: 'Hubungi Kami', id: 'contact' },
              ].map((item) => (
                <li key={item.id}>
                  <button
                    onClick={() => onNavigate(item.id)}
                    className={`hover:text-amber-400 transition-colors duration-150 text-left ${
                      activePage === item.id ? 'text-amber-400 font-medium' : 'text-gray-400'
                    }`}
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Details Column */}
          <div className="space-y-4">
            <h4 className="font-display font-semibold text-white uppercase tracking-wider text-sm border-b border-emerald-950 pb-2">
              Sekretariat Pusat
            </h4>
            <ul className="space-y-3 text-sm text-gray-400">
              <li className="flex items-start space-x-3">
                <MapPin size={18} className="text-amber-400 shrink-0 mt-0.5" />
                <span>
                  Jl. Jenderal Sudirman No. 45, Turikale, Kec. Turikale, Kabupaten Maros, Sulawesi Selatan 90511
                </span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone size={18} className="text-amber-400 shrink-0" />
                <span>+62 812-4455-8899</span>
              </li>
              <li className="flex items-center space-x-3">
                <Mail size={18} className="text-amber-400 shrink-0" />
                <span>info@hppmimaros.org</span>
              </li>
            </ul>
          </div>

        </div>

        <div className="border-t border-emerald-950 mt-12 pt-6 flex flex-col sm:flex-row justify-between items-center text-xs text-gray-500">
          <p>© {currentYear} Pengurus Pusat HPPMI Maros. Hak Cipta Dilindungi Undang-Undang.</p>
          <p className="mt-2 sm:mt-0">
            Didesain dengan nuansa hijau khas Maros Buttata Toa.
          </p>
        </div>
      </div>
    </footer>
  );
}
