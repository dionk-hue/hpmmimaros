/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Search, Shield, ArrowRight, MessageSquare } from 'lucide-react';

// Import Types
import { NewsArticle, PortfolioItem, OrgMember, ContactMessage } from './types.ts';

// Import Custom Pages
import Home from './pages/Home.tsx';
import AboutPortfolio from './pages/AboutPortfolio.tsx';
import NewsPortal from './pages/NewsPortal.tsx';
import NewsDetail from './pages/NewsDetail.tsx';
import Contact from './pages/Contact.tsx';
import AdminLogin from './pages/AdminLogin.tsx';
import AdminDashboard from './pages/AdminDashboard.tsx';

// Import Core Layout Elements
import Emblem from './components/Emblem.tsx';
import Footer from './components/Footer.tsx';

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [newsSlug, setNewsSlug] = useState<string>(''); // For News Detail viewing
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Global search bar in Header
  const [headerSearch, setHeaderSearch] = useState('');

  // Admin authentication session
  const [adminSession, setAdminSession] = useState<{ token: string; email: string } | null>(null);

  // Core Data States
  const [news, setNews] = useState<NewsArticle[]>([]);
  const [portfolio, setPortfolio] = useState<PortfolioItem[]>([]);
  const [structure, setStructure] = useState<OrgMember[]>([]);
  const [messages, setMessages] = useState<ContactMessage[]>([]);

  // 1. Fetch public datasets initially
  const fetchData = async () => {
    try {
      const [resNews, resPortfolio, resStructure] = await Promise.all([
        fetch('/api/news'),
        fetch('/api/portfolio'),
        fetch('/api/structure')
      ]);

      if (resNews.ok) setNews(await resNews.ok ? await resNews.json() : []);
      if (resPortfolio.ok) setPortfolio(await resPortfolio.json());
      if (resStructure.ok) setStructure(await resStructure.json());
    } catch (e) {
      console.error('Failed to load portal datasets:', e);
    }
  };

  // 2. Fetch secure messages (Requires Admin Session)
  const fetchMessages = async (token: string) => {
    try {
      const res = await fetch('/api/messages', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        setMessages(await res.json());
      } else if (res.status === 401) {
        handleLogout();
      }
    } catch (e) {
      console.error('Failed to load messages inbox:', e);
    }
  };

  // 3. Monitor Admin Session validation
  const checkAdminSessionOnMount = async () => {
    const savedToken = localStorage.getItem('hppmi_admin_token');
    const savedEmail = localStorage.getItem('hppmi_admin_email');

    if (savedToken && savedEmail) {
      try {
        const res = await fetch('/api/auth/check', {
          headers: { Authorization: `Bearer ${savedToken}` }
        });
        const data = await res.json();

        if (data.authenticated) {
          setAdminSession({ token: savedToken, email: savedEmail });
          fetchMessages(savedToken);
          // Auto-direct to dashboard if user is trying to access admin views
          if (currentPage === 'admin-login') {
            setCurrentPage('admin-dashboard');
          }
        } else {
          handleLogout();
        }
      } catch (e) {
        console.error('Failed to verify session on mount:', e);
        handleLogout();
      }
    }
  };

  // Sync routing state with URL pathname/history
  useEffect(() => {
    const handleUrlRouting = () => {
      const path = window.location.pathname;
      const searchParams = new URLSearchParams(window.location.search);
      
      if (path.startsWith('/news/') && path.length > 6) {
        const slug = path.substring(6);
        setNewsSlug(slug);
        setCurrentPage('news-detail');
      } else if (path === '/news' || path === '/news-portal') {
        setCurrentPage('news');
      } else if (path === '/about' || path === '/about-portfolio') {
        setCurrentPage('about');
      } else if (path === '/contact') {
        setCurrentPage('contact');
      } else if (path === '/admin-login') {
        setCurrentPage('admin-login');
      } else if (path === '/admin-dashboard') {
        setCurrentPage('admin-dashboard');
      } else if (searchParams.has('page')) {
        const page = searchParams.get('page')!;
        if (page === 'news-detail' && searchParams.has('slug')) {
          setNewsSlug(searchParams.get('slug')!);
        }
        setCurrentPage(page);
      } else {
        // Default to home
        if (path === '/' || path === '') {
          setCurrentPage('home');
        }
      }
    };

    // Run on mount
    handleUrlRouting();
    fetchData();
    checkAdminSessionOnMount();

    // Listen for state pop events (back/forward browser buttons)
    window.addEventListener('popstate', handleUrlRouting);
    return () => window.removeEventListener('popstate', handleUrlRouting);
  }, []);

  // Sync secure datasets on tab clicks or refreshes
  useEffect(() => {
    if (adminSession) {
      fetchMessages(adminSession.token);
    }
    // Pull public news / portfolio updates
    fetchData();
  }, [currentPage, adminSession]);

  // Synchronize browser document title based on currentPage
  useEffect(() => {
    if (currentPage === 'home') {
      document.title = 'PP HPPMI MAROS - Cendekia, Progresif & Mengabdi';
    } else if (currentPage === 'about') {
      document.title = 'Tentang & Portofolio Kerja - PP HPPMI MAROS';
    } else if (currentPage === 'news') {
      document.title = 'Portal Berita Terkini - PP HPPMI MAROS';
    } else if (currentPage === 'contact') {
      document.title = 'Hubungi Kami - PP HPPMI MAROS';
    } else if (currentPage === 'admin-login') {
      document.title = 'Login Administrator - PP HPPMI MAROS';
    } else if (currentPage === 'admin-dashboard') {
      document.title = 'Dashboard Pengurus - PP HPPMI MAROS';
    }
    // Note: 'news-detail' is fully managed internally inside NewsDetail component
  }, [currentPage]);

  const handleLoginSuccess = (token: string, email: string) => {
    setAdminSession({ token, email });
    fetchMessages(token);
    setCurrentPage('admin-dashboard');
    window.history.pushState(null, '', '/admin-dashboard');
  };

  const handleLogout = async () => {
    const token = localStorage.getItem('hppmi_admin_token');
    if (token) {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      }).catch(() => {});
    }
    localStorage.removeItem('hppmi_admin_token');
    localStorage.removeItem('hppmi_admin_email');
    setAdminSession(null);
    setMessages([]);
    setCurrentPage('home');
    window.history.pushState(null, '', '/');
  };

  // Header Search execution
  const handleHeaderSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (headerSearch.trim()) {
      setCurrentPage('news');
      window.history.pushState(null, '', '/news');
      setHeaderSearch('');
    }
  };

  const navigateTo = (page: string, params?: any) => {
    setMobileMenuOpen(false);
    if (page === 'news-detail' && typeof params === 'string') {
      setNewsSlug(params);
      setCurrentPage('news-detail');
      window.history.pushState(null, '', `/news/${params}`);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      setCurrentPage(page);
      const urlPath = page === 'home' ? '/' : `/${page}`;
      window.history.pushState(null, '', urlPath);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Nav items list
  const navItems = [
    { label: 'Beranda', id: 'home' },
    { label: 'Tentang & Program', id: 'about' },
    { label: 'Portal Berita', id: 'news' },
    { label: 'Hubungi Kami', id: 'contact' }
  ];

  const isAdminView = currentPage === 'admin-dashboard' || currentPage === 'admin-login';

  return (
    <div className="flex flex-col min-h-screen bg-[#F4F7F6] text-gray-800 antialiased">
      
      {/* 1. STICKY HEADER (Hidden in dedicated full-screen Admin View) */}
      {!isAdminView && (
        <header className="sticky top-0 z-40 bg-[#0B5345] text-white border-b border-emerald-900/40 shadow-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
            
            {/* Logo Block left */}
            <div
              onClick={() => navigateTo('home')}
              className="flex items-center space-x-3 cursor-pointer select-none shrink-0"
            >
              <Emblem size={44} />
              <div>
                <h3 className="font-display font-bold text-sm sm:text-base leading-tight uppercase tracking-wider text-white">
                  PP HPPMI MAROS
                </h3>
                <span className="text-[9px] font-mono tracking-widest text-amber-400 uppercase block">
                  Butta Salewangang
                </span>
              </div>
            </div>

            {/* Links Block Center (Desktop only) */}
            <nav className="hidden lg:flex items-center space-x-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => navigateTo(item.id)}
                  className={`px-4 py-2 rounded-lg text-sm font-display font-medium transition-colors duration-150 relative cursor-pointer ${
                    currentPage === item.id || (item.id === 'news' && currentPage === 'news-detail')
                      ? 'text-amber-400 font-semibold'
                      : 'text-gray-200 hover:text-white hover:bg-emerald-900/50'
                  }`}
                >
                  {item.label}
                  {(currentPage === item.id || (item.id === 'news' && currentPage === 'news-detail')) && (
                    <motion.div
                      layoutId="activeNavIndicator"
                      className="absolute bottom-0 inset-x-4 h-0.5 bg-amber-400 rounded-full"
                    />
                  )}
                </button>
              ))}
            </nav>

            {/* Actions Block Right (Desktop only: Search + Contact trigger + Admin console button) */}
            <div className="hidden lg:flex items-center space-x-4">
              {/* Header Search Box */}
              <form onSubmit={handleHeaderSearchSubmit} className="relative">
                <input
                  type="text"
                  placeholder="Cari Berita..."
                  value={headerSearch}
                  onChange={(e) => setHeaderSearch(e.target.value)}
                  className="bg-emerald-950/80 border border-emerald-900 text-xs px-3.5 pl-8 py-2 rounded-lg text-white focus:outline-none focus:border-amber-400 placeholder-emerald-300 w-44 focus:w-56 transition-all duration-300"
                />
                <Search size={13} className="absolute left-2.5 top-2.5 text-emerald-300" />
              </form>

              {/* Admin Portal Toggle */}
              <button
                onClick={() => navigateTo(adminSession ? 'admin-dashboard' : 'admin-login')}
                className="p-2 bg-emerald-900/60 border border-emerald-800 text-amber-400 hover:text-white hover:bg-emerald-900 rounded-lg transition"
                title="Konsol Admin Pengurus"
              >
                <Shield size={16} />
              </button>

              {/* Action Button */}
              <button
                onClick={() => navigateTo('contact')}
                className="px-4 py-2 bg-amber-400 text-emerald-950 font-bold text-xs uppercase tracking-wide rounded-lg hover:bg-amber-300 shadow hover:shadow-emerald-950/20 flex items-center space-x-1.5 transition cursor-pointer"
              >
                <MessageSquare size={13} />
                <span>Hubungi Kami</span>
              </button>
            </div>

            {/* Mobile Hamburger toggle button (Lg only) */}
            <div className="flex items-center lg:hidden space-x-3">
              <button
                onClick={() => navigateTo(adminSession ? 'admin-dashboard' : 'admin-login')}
                className="p-2.5 bg-emerald-900/60 border border-emerald-800 text-amber-400 rounded-lg transition"
              >
                <Shield size={15} />
              </button>

              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2.5 bg-emerald-900/60 border border-emerald-800 hover:bg-emerald-900 rounded-lg text-white transition cursor-pointer"
              >
                {mobileMenuOpen ? <X size={18} /> : <Menu size={18} />}
              </button>
            </div>

          </div>
        </header>
      )}

      {/* 2. MOBILE MENU DROPDOWN DRAWER */}
      <AnimatePresence>
        {mobileMenuOpen && !isAdminView && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-[#0a4d40] border-b border-emerald-900 text-white relative z-30"
          >
            <div className="px-4 py-4 space-y-3 font-semibold text-sm">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => navigateTo(item.id)}
                  className={`w-full text-left py-2.5 px-4 rounded-lg flex items-center justify-between ${
                    currentPage === item.id ? 'bg-[#117A65] text-amber-400' : 'hover:bg-emerald-900 text-gray-200'
                  }`}
                >
                  <span>{item.label}</span>
                  <ArrowRight size={14} className="opacity-50" />
                </button>
              ))}
              
              <div className="border-t border-emerald-900 pt-3 flex flex-col space-y-2.5">
                <button
                  onClick={() => navigateTo('contact')}
                  className="w-full text-center py-2.5 bg-amber-400 text-emerald-950 rounded-lg font-bold uppercase tracking-wide text-xs"
                >
                  Hubungi Kami
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 3. DYNAMIC CONTENT ROUTER PANEL */}
      <main className="flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage + (currentPage === 'news-detail' ? newsSlug : '')}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25 }}
          >
            {currentPage === 'home' && (
              <Home news={news} onNavigate={navigateTo} />
            )}

            {currentPage === 'about' && (
              <AboutPortfolio structure={structure} portfolio={portfolio} />
            )}

            {currentPage === 'news' && (
              <NewsPortal news={news} onNavigate={navigateTo} />
            )}

            {currentPage === 'news-detail' && (
              <NewsDetail slug={newsSlug} news={news} onNavigate={navigateTo} />
            )}

            {currentPage === 'contact' && (
              <Contact />
            )}

            {currentPage === 'admin-login' && (
              <AdminLogin
                onLoginSuccess={handleLoginSuccess}
                onNavigateHome={() => navigateTo('home')}
              />
            )}

            {currentPage === 'admin-dashboard' && adminSession && (
              <AdminDashboard
                token={adminSession.token}
                email={adminSession.email}
                onLogout={handleLogout}
                onRefreshData={fetchData}
                news={news}
                portfolio={portfolio}
                structure={structure}
                messages={messages}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* 4. FOOTER (Hidden in full-screen Admin Panels) */}
      {!isAdminView && (
        <Footer onNavigate={navigateTo} activePage={currentPage} />
      )}

    </div>
  );
}
