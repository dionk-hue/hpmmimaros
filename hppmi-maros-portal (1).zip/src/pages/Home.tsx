/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Users, BookOpen, MapPin, Award, Calendar, Eye, Shield, Send } from 'lucide-react';
import { NewsArticle } from '../types.ts';

interface HomeProps {
  news: NewsArticle[];
  onNavigate: (page: string, params?: any) => void;
}

export default function Home({ news, onNavigate }: HomeProps) {
  // Get latest 3 news articles
  const latestNews = news.slice(0, 3);

  // Stats Data
  const stats = [
    { label: 'Kader Terbina', value: '5,000+', icon: Users, desc: 'Tersebar di seluruh Indonesia' },
    { label: 'Komisariat & Cabang', value: '32+', icon: BookOpen, desc: 'Kampus & Kecamatan' },
    { label: 'Kawasan Pengabdian', value: '14', icon: MapPin, desc: 'Kecamatan di Kab. Maros' },
    { label: 'Program Unggulan', value: '15+', icon: Award, desc: 'Bakti sosial, Kajian & Olahraga' },
  ];

  return (
    <div className="bg-[#F4F7F6] min-h-screen">
      {/* 1. HERO SECTION */}
      <section className="relative bg-[#052821] text-white overflow-hidden py-24 sm:py-32">
        {/* Ambient Overlay background */}
        <div className="absolute inset-0 z-0 bg-cover bg-center opacity-20" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=1600&auto=format&fit=crop&q=80')" }}></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-emerald-500/25 via-transparent to-transparent opacity-40 z-0"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-[#052821] via-[#052821]/80 to-transparent z-0"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center space-x-2 bg-emerald-950/80 border border-emerald-500/30 px-3.5 py-1.5 rounded-full text-amber-400 text-xs font-mono tracking-wide uppercase"
            >
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
              <span>Official Portal PP HPPMI Maros</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="font-display font-bold text-3xl sm:text-5xl lg:text-6xl tracking-tight leading-tight"
            >
              Cendekia, <span className="text-amber-400">Progresif</span> & Mengabdi Untuk Maros
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-gray-300 text-base sm:text-lg max-w-2xl mx-auto leading-relaxed"
            >
              Selamat datang di website resmi Himpunan Pemuda Pelajar Mahasiswa Indonesia Maros. Wadah pergerakan kepemudaan, pendidikan, dan advokasi sosial terdepan di Kabupaten Maros.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4"
            >
              <button
                onClick={() => onNavigate('news')}
                className="w-full sm:w-auto px-6 py-3 bg-[#117A65] hover:bg-[#138D75] text-white font-semibold rounded-lg shadow-lg hover:shadow-emerald-950/50 flex items-center justify-center space-x-2 transition duration-200 group cursor-pointer"
              >
                <span>Mulai Jelajahi Berita</span>
                <ArrowRight size={18} className="transform group-hover:translate-x-1 transition-transform" />
              </button>
              <button
                onClick={() => onNavigate('about')}
                className="w-full sm:w-auto px-6 py-3 bg-transparent hover:bg-white/10 text-white font-semibold rounded-lg border border-white/20 transition duration-200 cursor-pointer"
              >
                Tentang & Program Kami
              </button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 2. OVERLAPPING STATS CARDS */}
      <section className="relative z-20 -mt-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, idx) => {
            const IconComponent = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="bg-white rounded-xl shadow-lg border border-emerald-900/5 p-6 flex items-start space-x-4 hover:shadow-xl hover:-translate-y-1 transition duration-200"
              >
                <div className="p-3 bg-[#E8F8F5] rounded-xl text-[#117A65]">
                  <IconComponent size={24} />
                </div>
                <div>
                  <h3 className="font-display font-bold text-2xl text-gray-900 leading-tight">
                    {stat.value}
                  </h3>
                  <p className="text-xs font-mono font-bold text-[#0B5345] uppercase tracking-wider mt-0.5">
                    {stat.label}
                  </p>
                  <p className="text-xs text-gray-500 mt-1 leading-snug">{stat.desc}</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* 3. LATEST NEWS GRID SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div className="space-y-2">
            <span className="text-[#117A65] font-mono text-xs tracking-widest uppercase font-bold">
              Kabar Terbaru Maros
            </span>
            <h2 className="font-display font-bold text-2xl sm:text-4xl text-gray-900">
              Portal Berita Terkini
            </h2>
          </div>
          <button
            onClick={() => onNavigate('news')}
            className="mt-4 md:mt-0 flex items-center space-x-1.5 text-[#117A65] font-display font-semibold hover:text-[#0B5345] transition-colors group cursor-pointer"
          >
            <span>Lihat Semua Berita</span>
            <ArrowRight size={16} className="transform group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {latestNews.length > 0 ? (
            latestNews.map((item, idx) => (
              <motion.article
                key={item.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: idx * 0.15 }}
                className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-100 flex flex-col hover:shadow-lg transition-shadow duration-200"
              >
                {/* News Thumbnail */}
                <div className="relative aspect-video overflow-hidden bg-gray-100 shrink-0">
                  <img
                    src={item.thumbnail}
                    alt={item.title}
                    loading="lazy"
                    className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                  <span className="absolute top-3 left-3 bg-[#0B5345] text-amber-400 font-mono text-[10px] font-bold tracking-wider uppercase px-2.5 py-1 rounded-full shadow-sm">
                    {item.category}
                  </span>
                </div>

                {/* News Details */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-4 text-xs text-gray-500 font-medium">
                      <span className="flex items-center space-x-1">
                        <Calendar size={13} />
                        <span>
                          {new Date(item.publishedAt).toLocaleDateString('id-ID', {
                            day: 'numeric',
                            month: 'short',
                            year: 'numeric',
                          })}
                        </span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <Eye size={13} />
                        <span>{item.views || 0} Kali</span>
                      </span>
                    </div>

                    <h3
                      onClick={() => onNavigate('news-detail', item.slug)}
                      className="font-display font-bold text-lg text-gray-900 leading-snug line-clamp-2 hover:text-[#117A65] transition-colors cursor-pointer"
                    >
                      {item.title}
                    </h3>

                    {/* Description Snippet */}
                    <p
                      className="text-sm text-gray-600 line-clamp-3 leading-relaxed"
                      dangerouslySetInnerHTML={{
                        __html: item.content.replace(/<[^>]*>/g, '').substring(0, 110) + '...',
                      }}
                    />
                  </div>

                  <div className="pt-5 mt-5 border-t border-gray-100 flex items-center justify-between">
                    <span className="text-xs text-gray-500">
                      Penulis: <span className="font-semibold text-gray-700">{item.author}</span>
                    </span>
                    <button
                      onClick={() => onNavigate('news-detail', item.slug)}
                      className="text-xs font-bold text-[#117A65] hover:text-[#0B5345] flex items-center space-x-1 group cursor-pointer"
                    >
                      <span>Baca Selengkapnya</span>
                      <ArrowRight size={14} className="transform group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  </div>
                </div>
              </motion.article>
            ))
          ) : (
            <div className="col-span-3 text-center py-12 bg-white rounded-xl border border-dashed border-gray-200">
              <p className="text-gray-500 text-sm">Tidak ada berita terbaru saat ini.</p>
            </div>
          )}
        </div>
      </section>

      {/* 4. STATISTICS & ABOUT BRIEF SNIPPET */}
      <section className="bg-emerald-50/50 py-20 border-y border-emerald-100/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Visual Block left */}
            <div className="lg:col-span-5 relative">
              <div className="relative aspect-[4/3] rounded-2xl overflow-hidden shadow-xl border-4 border-white bg-emerald-950">
                <img
                  src="https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&auto=format&fit=crop&q=80"
                  alt="HPPMI Maros Action"
                  className="w-full h-full object-cover opacity-85"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/80 to-transparent"></div>
                <div className="absolute bottom-6 left-6 text-white space-y-1">
                  <p className="text-xs text-amber-400 font-mono tracking-widest uppercase">Tri Dharma HPPMI</p>
                  <p className="font-bold text-lg">Pendidikan, Kerakyatan, & Pengabdian</p>
                </div>
              </div>
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-amber-400/20 rounded-full blur-2xl z-0"></div>
              <div className="absolute -top-6 -left-6 w-32 h-32 bg-emerald-400/20 rounded-full blur-2xl z-0"></div>
            </div>

            {/* About text right */}
            <div className="lg:col-span-7 space-y-6">
              <span className="text-[#117A65] font-mono text-xs tracking-widest uppercase font-bold">
                Sekilas Tentang Kami
              </span>
              <h2 className="font-display font-bold text-2xl sm:text-4xl text-gray-900 leading-tight">
                Sejarah Singkat & Komitmen Perjuangan HPPMI Maros
              </h2>
              <div className="text-gray-600 space-y-4 text-sm sm:text-base leading-relaxed">
                <p>
                  Diriwayatkan dalam tonggak sejarah kepemudaan Butta Salewangang, HPPMI Maros didirikan sebagai ikatan pemersatu segenap potensi intelektual pemuda, pelajar, dan mahasiswa asal Kabupaten Maros di mana pun berada. Sejak kelahirannya, organisasi ini konsisten mengawal aspirasi kemasyarakatan serta berkontribusi konkret dalam pembangunan daerah Maros.
                </p>
                <p>
                  Kami meyakini bahwa pilar pendidikan, pemberdayaan kader kepemudaan, serta pengabdian masyarakat terpadu merupakan kunci utama untuk memajukan daerah. Melalui jejaring komisariat di berbagai universitas dan cabang kecamatan, HPPMI Maros terus berinovasi mendampingi masyarakat guna melahirkan pemimpin-pemimpin masa depan daerah yang berkarakter islami dan progresif.
                </p>
              </div>
              <div className="pt-2">
                <button
                  onClick={() => onNavigate('about')}
                  className="px-6 py-3 bg-[#0B5345] hover:bg-[#117A65] text-white font-semibold rounded-lg shadow-md flex items-center space-x-2 transition cursor-pointer"
                >
                  <span>Baca Sejarah & Visi Lengkap</span>
                  <ArrowRight size={16} />
                </button>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 5. QUICK LINKS / ANNOUNCEMENTS BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <div className="bg-gradient-to-r from-[#0B5345] to-[#16a085] rounded-2xl shadow-xl p-8 sm:p-12 relative overflow-hidden text-white">
          <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-2xl transform translate-x-12 -translate-y-12"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-amber-400/5 rounded-full blur-2xl transform -translate-x-12 translate-y-12"></div>

          <div className="max-w-2xl mx-auto space-y-6 relative z-10">
            <span className="bg-amber-400 text-emerald-950 font-mono text-[10px] font-bold tracking-widest uppercase px-3 py-1 rounded-full">
              Pusat Pelayanan & Aspirasi
            </span>
            <h2 className="font-display font-bold text-xl sm:text-3xl tracking-tight leading-tight">
              Ingin Berkolaborasi, Memberikan Saran, atau Menyampaikan Aspirasi Rakyat?
            </h2>
            <p className="text-gray-200 text-sm sm:text-base leading-relaxed">
              Dewan Pengurus Pusat HPPMI Maros membuka ruang selebar-lebarnya bagi segenap elemen masyarakat, pelajar, dan instansi pemerintahan untuk bersinergi dan berdiskusi demi kemajuan Kabupaten Maros tercinta.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
              <button
                onClick={() => onNavigate('contact')}
                className="px-6 py-3 bg-white text-[#0B5345] font-bold rounded-lg shadow hover:bg-gray-100 transition flex items-center space-x-2 cursor-pointer"
              >
                <Send size={16} />
                <span>Saluran Aspirasi</span>
              </button>
              <button
                onClick={() => onNavigate('about')}
                className="px-6 py-3 bg-emerald-950/40 text-amber-400 border border-amber-400/30 font-semibold rounded-lg hover:bg-emerald-950/60 transition cursor-pointer"
              >
                Lihat Agenda Kerja Kami
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
