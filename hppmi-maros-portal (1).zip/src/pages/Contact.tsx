/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Phone, Mail, Send, CheckCircle, Clock, Heart, AlertCircle } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    // Simple validations
    if (!formData.name || !formData.email || !formData.subject || !formData.message) {
      setError('Mohon lengkapi seluruh kolom formulir.');
      setLoading(false);
      return;
    }

    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Terjadi kesalahan saat mengirim pesan.');
      }

      setSuccess(true);
      setFormData({ name: '', email: '', subject: '', message: '' });
    } catch (err: any) {
      setError(err.message || 'Koneksi ke server gagal. Coba lagi nanti.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#F4F7F6] min-h-screen">
      {/* HEADER HERO */}
      <section className="bg-[#0B5345] text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px]"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-emerald-500/20 via-transparent to-transparent opacity-30"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4 relative z-10">
          <span className="text-amber-400 font-mono text-xs tracking-widest uppercase font-bold">
            Hubungan Masyarakat & Informasi
          </span>
          <h1 className="font-display font-bold text-3xl sm:text-5xl">Hubungi Kami</h1>
          <p className="text-gray-300 text-sm sm:text-base max-w-2xl mx-auto leading-relaxed">
            Punya pertanyaan seputar program kerja, permohonan kemitraan, atau aspirasi yang ingin disampaikan? Pengurus Pusat HPPMI Maros siap menyambut hangat pesan Anda.
          </p>
        </div>
      </section>

      {/* CONTACT BODY AREA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* CONTACT DETAILS & COORDINATES (LEFT) */}
          <div className="lg:col-span-5 space-y-8">
            <div className="space-y-4">
              <span className="text-[#117A65] font-mono text-xs tracking-widest uppercase font-bold">
                Kontak Resmi
              </span>
              <h2 className="font-display font-bold text-2xl text-gray-900 leading-tight">
                Hubungi Sekretariat Kami
              </h2>
              <p className="text-gray-600 text-sm leading-relaxed">
                Silakan hubungi kami melalui saluran surat menyurat resmi atau telepon berikut, atau kunjungi sekretariat kami langsung untuk melakukan audiensi langsung.
              </p>
            </div>

            {/* Direct Cards list */}
            <div className="space-y-4">
              <div className="bg-white border border-gray-100 rounded-xl shadow-sm p-5 flex items-start space-x-4">
                <div className="p-3 bg-emerald-50 rounded-xl text-[#117A65] shrink-0">
                  <MapPin size={22} />
                </div>
                <div className="space-y-1">
                  <h4 className="font-bold text-sm text-gray-900 uppercase tracking-wide">Alamat Fisik</h4>
                  <p className="text-xs text-gray-600 leading-relaxed">
                    Jl. Jenderal Sudirman No. 45, Turikale, Kec. Turikale, Kabupaten Maros, Sulawesi Selatan 90511
                  </p>
                </div>
              </div>

              <div className="bg-white border border-gray-100 rounded-xl shadow-sm p-5 flex items-start space-x-4">
                <div className="p-3 bg-emerald-50 rounded-xl text-[#117A65] shrink-0">
                  <Phone size={22} />
                </div>
                <div className="space-y-1">
                  <h4 className="font-bold text-sm text-gray-900 uppercase tracking-wide">Telepon & WhatsApp</h4>
                  <p className="text-xs text-gray-600 leading-relaxed">
                    +62 812-4455-8899 (Humas PP HPPMI)
                  </p>
                </div>
              </div>

              <div className="bg-white border border-gray-100 rounded-xl shadow-sm p-5 flex items-start space-x-4">
                <div className="p-3 bg-emerald-50 rounded-xl text-[#117A65] shrink-0">
                  <Mail size={22} />
                </div>
                <div className="space-y-1">
                  <h4 className="font-bold text-sm text-gray-900 uppercase tracking-wide">Surat Elektronik</h4>
                  <p className="text-xs text-gray-600 leading-relaxed">
                    info@hppmimaros.org / sekretariat@hppmimaros.org
                  </p>
                </div>
              </div>

              <div className="bg-white border border-gray-100 rounded-xl shadow-sm p-5 flex items-start space-x-4">
                <div className="p-3 bg-emerald-50 rounded-xl text-[#117A65] shrink-0">
                  <Clock size={22} />
                </div>
                <div className="space-y-1">
                  <h4 className="font-bold text-sm text-gray-900 uppercase tracking-wide">Jam Operasional</h4>
                  <p className="text-xs text-gray-600 leading-relaxed">
                    Senin - Sabtu: 09:00 - 17:00 WITA
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* DYNAMIC CONTACT FORM (RIGHT) */}
          <div className="lg:col-span-7 bg-white rounded-2xl border border-emerald-950/5 shadow-md p-8 sm:p-10">
            <h3 className="font-display font-bold text-xl text-gray-900 mb-6">
              Kirimkan Aspirasi / Pesan Anda
            </h3>

            <AnimatePresence mode="wait">
              {success ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="bg-[#E8F8F5] border border-emerald-100 rounded-xl p-6 text-center space-y-4"
                >
                  <CheckCircle size={44} className="text-[#117A65] mx-auto" />
                  <div className="space-y-1">
                    <h4 className="font-bold text-lg text-gray-900">Pesan Terkirim!</h4>
                    <p className="text-sm text-gray-600 max-w-sm mx-auto leading-relaxed">
                      Terima kasih banyak. Aspirasi/pesan Anda telah disimpan dalam basis data pengurus pusat HPPMI Maros dan akan segera ditinjau oleh Biro Humas.
                    </p>
                  </div>
                  <button
                    onClick={() => setSuccess(false)}
                    className="px-5 py-2 bg-[#0B5345] hover:bg-[#117A65] text-white text-xs font-semibold rounded-lg transition"
                  >
                    Kirim Pesan Lainnya
                  </button>
                </motion.div>
              ) : (
                <motion.form
                  onSubmit={handleSubmit}
                  className="space-y-6"
                >
                  {error && (
                    <div className="bg-red-50 border border-red-100 text-red-600 rounded-lg p-3.5 flex items-start space-x-2 text-xs font-medium">
                      <AlertCircle size={15} className="shrink-0 mt-0.5" />
                      <span>{error}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Nama Lengkap</label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Contoh: Muhammad Fajar"
                        className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:border-[#117A65] transition"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Alamat Email</label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="Contoh: fajar@email.com"
                        className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:border-[#117A65] transition"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Subjek Pesan / Kategori</label>
                    <input
                      type="text"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      placeholder="Contoh: Permohonan Kemitraan Kegiatan / Aspirasi Jalan Desa"
                      className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:border-[#117A65] transition"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Pernyataan Pesan / Aspirasi</label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      placeholder="Tuliskan aspirasi, kritik, saran, atau permohonan kemitraan Anda di sini secara detail..."
                      rows={5}
                      className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:border-[#117A65] transition resize-none"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 bg-[#0B5345] hover:bg-[#117A65] text-white font-bold rounded-lg shadow hover:shadow-emerald-950/20 flex items-center justify-center space-x-2 transition disabled:opacity-50 cursor-pointer"
                  >
                    {loading ? (
                      <span className="w-5 h-5 rounded-full border-2 border-white border-t-transparent animate-spin"></span>
                    ) : (
                      <>
                        <Send size={16} />
                        <span>Kirim Pesan Sekarang</span>
                      </>
                    )}
                  </button>
                </motion.form>
              )}
            </AnimatePresence>
          </div>

        </div>
      </section>

      {/* 4. REAL INTERACTIVE GOOGLE MAP EMBED OF MAROS REGENCY */}
      <section className="bg-white border-t border-gray-200">
        <div className="h-[450px] w-full relative">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d127170.8388439396!2d119.53123896503906!3d-5.011859664188599!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dbee136bfb1b723%3A0x301e8f1fc28da70!2sKabupaten%20Maros%2C%20Sulawesi%20Selatan!5e0!3m2!1sid!2sid!4v1720000000000!5m2!1sid!2sid"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen={false}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="Peta Wilayah Kabupaten Maros, Sulawesi Selatan"
          ></iframe>
          {/* Subtle overlay float badge */}
          <div className="absolute bottom-6 left-6 bg-white border border-gray-100 shadow-md p-4 rounded-xl flex items-center space-x-3 max-w-sm hidden sm:flex">
            <div className="p-2 bg-[#E8F8F5] text-[#117A65] rounded-lg shrink-0">
              <Heart size={18} className="fill-[#117A65]" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-gray-900 uppercase">Butta Salewangang</h4>
              <p className="text-[11px] text-gray-500 leading-tight">Maros, Sulawesi Selatan, Indonesia</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
