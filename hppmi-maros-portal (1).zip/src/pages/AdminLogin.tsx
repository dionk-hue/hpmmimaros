/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Lock, Mail, ArrowRight, AlertCircle, Eye, EyeOff } from 'lucide-react';
import Emblem from '../components/Emblem.tsx';

interface AdminLoginProps {
  onLoginSuccess: (token: string, email: string) => void;
  onNavigateHome: () => void;
}

export default function AdminLogin({ onLoginSuccess, onNavigateHome }: AdminLoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (!email || !password) {
      setError('Mohon isi email dan password.');
      setLoading(false);
      return;
    }

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Login gagal. Periksa kembali email dan password Anda.');
      }

      // Persist token in local storage
      localStorage.setItem('hppmi_admin_token', data.token);
      localStorage.setItem('hppmi_admin_email', data.email);

      // Trigger callback to parent
      onLoginSuccess(data.token, data.email);
    } catch (err: any) {
      setError(err.message || 'Gagal terhubung ke server.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#052821] flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background decoration bubbles */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-[#117A65]/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-amber-400/5 rounded-full blur-3xl"></div>

      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center relative z-10 space-y-4">
        <Emblem size={70} className="mx-auto filter drop-shadow" />
        <div className="space-y-1">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-sans tracking-tight">
            Konsol Pengurus Pusat
          </h2>
          <p className="text-sm text-emerald-300 font-mono uppercase tracking-wider">
            HPPMI Maros Admin Dashboard
          </p>
        </div>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white py-8 px-6 shadow-xl rounded-2xl border border-gray-100/50 sm:px-10 space-y-6"
        >
          {error && (
            <div className="bg-red-50 border border-red-100 text-red-600 rounded-lg p-3.5 flex items-start space-x-2 text-xs font-semibold leading-relaxed">
              <AlertCircle size={15} className="shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <div className="bg-emerald-50/50 border border-emerald-100 rounded-xl p-3 text-[11px] leading-relaxed text-gray-600">
            <p className="font-extrabold text-[#0B5345] uppercase tracking-wider mb-0.5">Kredensial Pengurus Pusat:</p>
            <p>Email: <span className="font-bold text-gray-800 font-mono">admin@hppmimaros.org</span></p>
            <p>Password: <span className="font-bold text-gray-800 font-mono">adminmaros2026</span></p>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-1.5">
              <label className="block text-xs font-extrabold text-gray-700 uppercase tracking-wide">
                Email Pengurus
              </label>
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@hppmimaros.org"
                  className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:border-[#117A65]"
                  required
                />
                <Mail size={16} className="absolute left-3.5 top-3.5 text-gray-400" />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-extrabold text-gray-700 uppercase tracking-wide">
                Kata Sandi
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-10 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:border-[#117A65]"
                  required
                />
                <Lock size={16} className="absolute left-3.5 top-3.5 text-gray-400" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-3.5 text-gray-400 hover:text-gray-600 transition"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-[#0B5345] hover:bg-[#117A65] text-white font-bold rounded-lg shadow-md hover:shadow-emerald-950/20 flex items-center justify-center space-x-2 transition disabled:opacity-50 cursor-pointer"
            >
              {loading ? (
                <span className="w-5 h-5 rounded-full border-2 border-white border-t-transparent animate-spin"></span>
              ) : (
                <>
                  <span>Masuk ke Konsol</span>
                  <ArrowRight size={16} />
                </>
              )}
            </button>
          </form>

          <div className="border-t border-gray-100 pt-4 text-center">
            <button
              onClick={onNavigateHome}
              className="text-xs text-gray-500 hover:text-[#117A65] font-medium transition cursor-pointer"
            >
              Kembali ke Beranda Website
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
