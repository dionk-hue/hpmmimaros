/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'motion/react';
import { Calendar, Eye, Share2, Facebook, Twitter, ChevronLeft, Link2, CheckCircle2, User, HelpCircle } from 'lucide-react';
import { NewsArticle } from '../types.ts';

interface NewsDetailProps {
  slug: string;
  news: NewsArticle[];
  onNavigate: (page: string, params?: any) => void;
}

export default function NewsDetail({ slug, news, onNavigate }: NewsDetailProps) {
  const [copied, setCopied] = useState(false);

  // 1. Fetch current article from news catalog
  const article = useMemo(() => {
    return news.find((item) => item.slug === slug);
  }, [news, slug]);

  // 2. Increment view count client-side (and query backend in background)
  useEffect(() => {
    if (article) {
      // Dynamic SEO Meta Title and Description update on client-side transitions
      document.title = `${article.title} - PP HPPMI MAROS`;
      
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) {
        let cleanContent = article.content || '';
        cleanContent = cleanContent
          .replace(/<\/?[^>]+(>|$)/g, '') // strip HTML
          .replace(/[#\*_`~\[\]\(\)\-]/g, ' ') // strip Markdown symbols
          .replace(/\s+/g, ' ')
          .trim();
        
        if (cleanContent.length > 160) {
          cleanContent = cleanContent.substring(0, 157) + '...';
        }
        metaDesc.setAttribute('content', cleanContent || 'Kabar berita resmi dari Pengurus Pusat HPPMI Maros.');
      }
      
      // Hit view counter endpoint
      fetch(`/api/news/${article.slug}`).catch((e) =>
        console.error('Failed to increment views on server:', e)
      );
    }

    return () => {
      document.title = 'PP HPPMI MAROS - Cendekia, Progresif & Mengabdi';
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) {
        metaDesc.setAttribute(
          'content',
          'Portal Resmi Pengurus Pusat Himpunan Pemuda Pelajar Mahasiswa Indonesia (HPPMI) Maros. Wadah perjuangan cendekia, progresif, dan mengabdi untuk Kabupaten Maros.'
        );
      }
    };
  }, [article]);

  // 3. Recommended related articles (same category, excluding current)
  const relatedArticles = useMemo(() => {
    if (!article) return [];
    return news
      .filter((item) => item.category === article.category && item.id !== article.id)
      .slice(0, 3);
  }, [news, article]);

  if (!article) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center space-y-4">
        <HelpCircle size={48} className="mx-auto text-amber-500 animate-bounce" />
        <h2 className="font-sans font-bold text-2xl text-gray-800">Artikel Tidak Ditemukan</h2>
        <p className="text-gray-500 text-sm">Berita yang Anda cari tidak tersedia atau telah dihapus oleh pengurus.</p>
        <button
          onClick={() => onNavigate('news')}
          className="px-6 py-2.5 bg-[#0B5345] hover:bg-[#117A65] text-white font-semibold rounded-lg shadow cursor-pointer transition"
        >
          Kembali ke Portal Berita
        </button>
      </div>
    );
  }

  const shareUrl = window.location.href;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-[#F4F7F6] min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* BACK TO PORTAL LINK */}
        <button
          onClick={() => onNavigate('news')}
          className="inline-flex items-center space-x-1.5 text-[#117A65] hover:text-[#0B5345] text-sm font-display font-semibold transition group cursor-pointer"
        >
          <ChevronLeft size={16} className="transform group-hover:-translate-x-0.5 transition-transform" />
          <span>Kembali ke Portal Berita</span>
        </button>

        {/* MAIN ARTICLE DETAIL CONTAINER */}
        <motion.article
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl border border-emerald-950/5 shadow-sm overflow-hidden"
        >
          {/* Cover image */}
          <div className="aspect-[21/9] bg-gray-100 relative overflow-hidden">
            <img
              src={article.thumbnail}
              alt={article.title}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <span className="absolute bottom-4 left-4 bg-[#0B5345] text-amber-400 font-mono text-xs font-bold tracking-widest px-3 py-1.5 rounded-lg uppercase shadow-md">
              {article.category}
            </span>
          </div>

          <div className="p-6 sm:p-10 space-y-6">
            
            {/* Metadata bar */}
            <div className="flex flex-wrap items-center gap-4 text-xs text-gray-500 font-medium pb-4 border-b border-gray-100">
              <span className="flex items-center space-x-1.5">
                <User size={13} className="text-[#117A65]" />
                <span>Penulis: <span className="font-semibold text-gray-700">{article.author}</span></span>
              </span>
              <span className="flex items-center space-x-1.5">
                <Calendar size={13} className="text-[#117A65]" />
                <span>
                  {new Date(article.publishedAt).toLocaleDateString('id-ID', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  })} WITA
                </span>
              </span>
              <span className="flex items-center space-x-1.5">
                <Eye size={13} className="text-[#117A65]" />
                <span>Dilihat {article.views || 0} Kali</span>
              </span>
            </div>

            {/* Title */}
            <h1 className="font-display font-bold text-2xl sm:text-3xl lg:text-4xl text-gray-900 leading-snug">
              {article.title}
            </h1>

            {/* Simulated Share floating buttons */}
            <div className="flex flex-wrap items-center gap-2 pt-2">
              <span className="text-xs font-bold uppercase tracking-wider text-gray-400 mr-2 flex items-center space-x-1">
                <Share2 size={12} />
                <span>Bagikan Kabar:</span>
              </span>
              <a
                href={`https://api.whatsapp.com/send?text=${encodeURIComponent(article.title + ' ' + shareUrl)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-[#25D366] text-white hover:bg-[#128C7E] text-xs font-bold shadow-sm transition"
              >
                <span>WhatsApp</span>
              </a>
              <a
                href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-[#1877F2] text-white hover:bg-[#165EBF] text-xs font-bold shadow-sm transition"
              >
                <Facebook size={12} />
                <span>Facebook</span>
              </a>
              <a
                href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(article.title)}&url=${encodeURIComponent(shareUrl)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-[#1DA1F2] text-white hover:bg-[#1a91da] text-xs font-bold shadow-sm transition"
              >
                <Twitter size={12} />
                <span>Twitter</span>
              </a>
              <button
                onClick={handleCopyLink}
                className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-bold border border-gray-200 transition cursor-pointer"
              >
                {copied ? <CheckCircle2 size={12} className="text-emerald-500" /> : <Link2 size={12} />}
                <span>{copied ? 'Tersalin' : 'Salin Tautan'}</span>
              </button>
            </div>

            {/* Content area */}
            <div
              className="prose prose-emerald prose-base sm:prose-lg max-w-none text-gray-800 leading-relaxed space-y-4 pt-4 border-t border-gray-100"
              dangerouslySetInnerHTML={{ __html: article.content }}
            />

            {/* Tags section */}
            {article.tags && article.tags.length > 0 && (
              <div className="pt-6 border-t border-gray-100 flex flex-wrap gap-2">
                {article.tags.map((tag) => (
                  <span
                    key={tag}
                    className="bg-emerald-50 text-[#0B5345] border border-emerald-100 text-xs font-semibold px-3 py-1 rounded-md"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            )}

          </div>
        </motion.article>

        {/* RELATED ARTICLES WIDGET */}
        {relatedArticles.length > 0 && (
          <div className="space-y-6 pt-6">
            <h3 className="font-display font-bold text-lg text-gray-900 uppercase tracking-wider border-l-4 border-[#117A65] pl-3">
              Kabar Terkait Lainnya
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {relatedArticles.map((rel) => (
                <div
                  key={rel.id}
                  onClick={() => onNavigate('news-detail', rel.slug)}
                  className="bg-white rounded-xl border border-emerald-950/5 shadow-sm overflow-hidden flex flex-col justify-between hover:shadow-md cursor-pointer group transition duration-150"
                >
                  <div className="aspect-video bg-gray-100 overflow-hidden relative">
                    <img
                      src={rel.thumbnail}
                      alt={rel.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-200"
                      referrerPolicy="no-referrer"
                    />
                    <span className="absolute top-2 left-2 bg-[#0B5345] text-amber-400 font-mono text-[8px] font-bold tracking-wider px-2 py-0.5 rounded-lg uppercase">
                      {rel.category}
                    </span>
                  </div>
                  <div className="p-4 flex-1 flex flex-col justify-between space-y-2">
                    <h4 className="font-display font-bold text-xs sm:text-sm text-gray-800 group-hover:text-[#117A65] transition line-clamp-2 leading-snug">
                      {rel.title}
                    </h4>
                    <span className="text-[10px] text-gray-400 font-mono flex items-center space-x-1">
                      <Calendar size={10} />
                      <span>
                        {new Date(rel.publishedAt).toLocaleDateString('id-ID', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </span>
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
