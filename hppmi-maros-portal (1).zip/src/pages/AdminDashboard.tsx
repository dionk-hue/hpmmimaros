/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  LayoutDashboard, Newspaper, Award, Users, Mail, LogOut, Plus, Trash2, Edit2, Check, ExternalLink,
  Search, Eye, Calendar, User, Tag, Image, Upload, AlertCircle, RefreshCw, X
} from 'lucide-react';
import { NewsArticle, PortfolioItem, OrgMember, ContactMessage, DashboardStats } from '../types.ts';
import RichTextEditor from '../components/RichTextEditor.tsx';

// Stock Photo Presets for quick admin convenience
const PHOTO_PRESETS = {
  news: [
    { label: 'Rapat / Acara', url: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&auto=format&fit=crop&q=60' },
    { label: 'Pendidikan / Beasiswa', url: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=800&auto=format&fit=crop&q=60' },
    { label: 'Bakti Sosial', url: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=800&auto=format&fit=crop&q=60' },
    { label: 'Geopark Karst / Alam', url: 'https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=800&auto=format&fit=crop&q=60' },
    { label: 'Kerja Tim / Kolaborasi', url: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800&auto=format&fit=crop&q=60' }
  ],
  members: [
    { label: 'Pria Formal 1', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=60' },
    { label: 'Pria Formal 2', url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=60' },
    { label: 'Pria Formal 3', url: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&auto=format&fit=crop&q=60' },
    { label: 'Wanita Formal 1', url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=60' },
    { label: 'Wanita Formal 2', url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=60' },
    { label: 'Wanita Formal 3', url: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&auto=format&fit=crop&q=60' }
  ]
};

interface AdminDashboardProps {
  token: string;
  email: string;
  onLogout: () => void;
  onRefreshData: () => void;
  news: NewsArticle[];
  portfolio: PortfolioItem[];
  structure: OrgMember[];
  messages: ContactMessage[];
}

export default function AdminDashboard({
  token,
  email,
  onLogout,
  onRefreshData,
  news,
  portfolio,
  structure,
  messages
}: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'news' | 'portfolio' | 'structure' | 'messages'>('overview');

  // Unified Loading and Alert state managers
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Search filter managers
  const [newsSearch, setNewsSearch] = useState('');
  const [msgSearch, setMsgSearch] = useState('');

  // Core stats
  const [stats, setStats] = useState<DashboardStats>({
    totalNews: news.length,
    totalMessages: messages.length,
    totalPrograms: portfolio.length,
    totalMembers: structure.length
  });

  // Fetch metrics dynamically on change
  const refreshStats = async () => {
    try {
      const res = await fetch('/api/stats');
      if (res.ok) {
        const data = await res.json();
        setStats(data);
      }
    } catch (e) {
      console.error('Failed to reload dashboard stats:', e);
    }
  };

  useEffect(() => {
    refreshStats();
  }, [news, portfolio, structure, messages]);

  const showFeedback = (type: 'success' | 'error', text: string) => {
    setFeedback({ type, text });
    setTimeout(() => setFeedback(null), 4000);
  };

  // --- FORM STATE MANAGERS & TRIGGERS ---
  const [newsForm, setNewsForm] = useState({
    id: '', // Empty means creating new
    title: '',
    category: 'internal HPPMI',
    content: '',
    author: 'Humas PP HPPMI',
    tagsInput: '',
    thumbnail: PHOTO_PRESETS.news[0].url,
    showForm: false
  });

  const [progForm, setProgForm] = useState({
    id: '',
    title: '',
    description: '',
    category: 'Ongoing',
    targetDate: '',
    participants: '',
    imageUrl: PHOTO_PRESETS.news[2].url,
    showForm: false
  });

  const [memberForm, setMemberForm] = useState({
    id: '',
    name: '',
    role: '',
    department: 'BPH',
    order: 1,
    photoUrl: PHOTO_PRESETS.members[0].url,
    showForm: false
  });

  const [viewingMessage, setViewingMessage] = useState<ContactMessage | null>(null);

  // File to Base64 helper for dynamic uploads
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, formType: 'news' | 'prog' | 'member') => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      showFeedback('error', 'Ukuran foto maksimal adalah 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      if (formType === 'news') {
        setNewsForm((prev) => ({ ...prev, thumbnail: base64 }));
      } else if (formType === 'prog') {
        setProgForm((prev) => ({ ...prev, imageUrl: base64 }));
      } else if (formType === 'member') {
        setMemberForm((prev) => ({ ...prev, photoUrl: base64 }));
      }
      showFeedback('success', 'Foto terunggah dan terkompresi secara lokal!');
    };
    reader.readAsDataURL(file);
  };

  // --- CRUD ACTIONS: NEWS ARTICLES ---
  const handleSaveNews = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsForm.title || !newsForm.content || !newsForm.category) {
      showFeedback('error', 'Mohon lengkapi seluruh judul, kategori, dan isi berita.');
      return;
    }

    setLoading(true);
    const tags = newsForm.tagsInput
      .split(',')
      .map((t) => t.trim())
      .filter((t) => t.length > 0);

    const payload = {
      title: newsForm.title,
      content: newsForm.content,
      category: newsForm.category,
      author: newsForm.author,
      thumbnail: newsForm.thumbnail,
      tags
    };

    const isEdit = !!newsForm.id;
    const url = isEdit ? `/api/news/${newsForm.id}` : '/api/news';
    const method = isEdit ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        if (res.status === 401) onLogout();
        const errData = await res.json();
        throw new Error(errData.error || 'Gagal menyimpan berita.');
      }

      showFeedback('success', isEdit ? 'Artikel berita diperbarui!' : 'Artikel berita diterbitkan!');
      setNewsForm({
        id: '',
        title: '',
        category: 'internal HPPMI',
        content: '',
        author: 'Humas PP HPPMI',
        tagsInput: '',
        thumbnail: PHOTO_PRESETS.news[0].url,
        showForm: false
      });
      onRefreshData();
    } catch (err: any) {
      showFeedback('error', err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteNews = async (id: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus berita ini secara permanen?')) return;

    try {
      const res = await fetch(`/api/news/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });

      if (!res.ok) {
        if (res.status === 401) onLogout();
        throw new Error('Gagal menghapus berita.');
      }

      showFeedback('success', 'Berita berhasil dihapus.');
      onRefreshData();
    } catch (err: any) {
      showFeedback('error', err.message);
    }
  };

  // --- CRUD ACTIONS: PORTFOLIO PROGRAMS ---
  const handleSaveProgram = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!progForm.title || !progForm.description || !progForm.targetDate) {
      showFeedback('error', 'Lengkapi judul, uraian, dan jadwal program.');
      return;
    }

    setLoading(true);
    const payload = {
      title: progForm.title,
      description: progForm.description,
      category: progForm.category,
      targetDate: progForm.targetDate,
      participants: progForm.participants,
      imageUrl: progForm.imageUrl
    };

    const isEdit = !!progForm.id;
    const url = isEdit ? `/api/portfolio/${progForm.id}` : '/api/portfolio';
    const method = isEdit ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        if (res.status === 401) onLogout();
        throw new Error('Gagal menyimpan program kerja.');
      }

      showFeedback('success', isEdit ? 'Program kerja diperbarui!' : 'Program kerja ditambahkan!');
      setProgForm({
        id: '',
        title: '',
        description: '',
        category: 'Ongoing',
        targetDate: '',
        participants: '',
        imageUrl: PHOTO_PRESETS.news[2].url,
        showForm: false
      });
      onRefreshData();
    } catch (err: any) {
      showFeedback('error', err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteProgram = async (id: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus program ini?')) return;

    try {
      const res = await fetch(`/api/portfolio/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });

      if (!res.ok) {
        if (res.status === 401) onLogout();
        throw new Error('Gagal menghapus program.');
      }

      showFeedback('success', 'Program kerja dihapus.');
      onRefreshData();
    } catch (err: any) {
      showFeedback('error', err.message);
    }
  };

  // --- CRUD ACTIONS: STRUCTURAL MEMBERS ---
  const handleSaveMember = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!memberForm.name || !memberForm.role) {
      showFeedback('error', 'Lengkapi nama dan jabatan pengurus.');
      return;
    }

    setLoading(true);
    const payload = {
      name: memberForm.name,
      role: memberForm.role,
      department: memberForm.department,
      order: Number(memberForm.order) || 1,
      photoUrl: memberForm.photoUrl
    };

    const isEdit = !!memberForm.id;
    const url = isEdit ? `/api/structure/${memberForm.id}` : '/api/structure';
    const method = isEdit ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        if (res.status === 401) onLogout();
        throw new Error('Gagal menyimpan pengurus.');
      }

      showFeedback('success', isEdit ? 'Profil pengurus diperbarui!' : 'Pengurus baru ditambahkan!');
      setMemberForm({
        id: '',
        name: '',
        role: '',
        department: 'BPH',
        order: 1,
        photoUrl: PHOTO_PRESETS.members[0].url,
        showForm: false
      });
      onRefreshData();
    } catch (err: any) {
      showFeedback('error', err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteMember = async (id: string) => {
    if (!confirm('Hapus profil pengurus ini secara permanen dari bagan organisasi?')) return;

    try {
      const res = await fetch(`/api/structure/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });

      if (!res.ok) {
        if (res.status === 401) onLogout();
        throw new Error('Gagal menghapus pengurus.');
      }

      showFeedback('success', 'Pengurus telah dihapus.');
      onRefreshData();
    } catch (err: any) {
      showFeedback('error', err.message);
    }
  };

  // --- CONSOLE: MESSAGE INBOX CENTER ---
  const handleReadMessage = async (msg: ContactMessage) => {
    setViewingMessage(msg);
    if (msg.status === 'unread') {
      try {
        const res = await fetch(`/api/messages/${msg.id}/read`, {
          method: 'PUT',
          headers: { Authorization: `Bearer ${token}` }
        });
        if (res.ok) {
          onRefreshData();
        }
      } catch (e) {
        console.error('Failed to mark message as read:', e);
      }
    }
  };

  const handleDeleteMessage = async (id: string) => {
    if (!confirm('Hapus pesan aspirasi ini?')) return;

    try {
      const res = await fetch(`/api/messages/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });

      if (!res.ok) {
        if (res.status === 401) onLogout();
        throw new Error('Gagal menghapus pesan.');
      }

      showFeedback('success', 'Pesan berhasil dihapus.');
      setViewingMessage(null);
      onRefreshData();
    } catch (err: any) {
      showFeedback('error', err.message);
    }
  };

  // Filters application
  const filteredNews = news.filter(
    (n) => n.title.toLowerCase().includes(newsSearch.toLowerCase()) || n.author.toLowerCase().includes(newsSearch.toLowerCase())
  );

  const filteredMessages = messages.filter(
    (m) =>
      m.name.toLowerCase().includes(msgSearch.toLowerCase()) ||
      m.subject.toLowerCase().includes(msgSearch.toLowerCase()) ||
      m.message.toLowerCase().includes(msgSearch.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col md:flex-row font-sans">
      
      {/* SIDEBAR NAVIGATION AREA (LEFT) */}
      <aside className="md:w-64 bg-[#052821] text-gray-300 flex flex-col justify-between border-r border-emerald-950 shrink-0">
        <div>
          {/* Logo Brand top */}
          <div className="p-6 border-b border-emerald-950 flex items-center space-x-3 bg-[#031d18]">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <div>
              <h2 className="font-bold text-white tracking-wide text-sm leading-tight uppercase">HPPMI Admin</h2>
              <span className="text-[10px] text-amber-400 font-mono">Pusat Pengendalian</span>
            </div>
          </div>

          {/* Nav Links */}
          <nav className="p-4 space-y-1.5 text-sm">
            {[
              { id: 'overview', label: 'Ringkasan', icon: LayoutDashboard },
              { id: 'news', label: 'Kelola Berita', icon: Newspaper },
              { id: 'portfolio', label: 'Kelola Program', icon: Award },
              { id: 'structure', label: 'Bagan Pengurus', icon: Users },
              { id: 'messages', label: 'Pesan Masuk', icon: Mail, badge: messages.filter((m) => m.status === 'unread').length }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id as any);
                    // Reset drawers on navigation
                    setNewsForm((prev) => ({ ...prev, showForm: false }));
                    setProgForm((prev) => ({ ...prev, showForm: false }));
                    setMemberForm((prev) => ({ ...prev, showForm: false }));
                  }}
                  className={`w-full flex items-center justify-between px-4 py-2.5 rounded-lg transition-colors cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-[#117A65] text-white font-semibold'
                      : 'hover:bg-emerald-950 hover:text-white text-gray-400'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <Icon size={18} />
                    <span>{tab.label}</span>
                  </div>
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span className="bg-amber-400 text-emerald-950 font-bold font-mono text-[10px] px-2 py-0.5 rounded-full">
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* User profile section bottom */}
        <div className="p-4 border-t border-emerald-950 space-y-3 bg-[#031d18]/40">
          <div className="flex items-center space-x-3 px-2">
            <div className="w-8 h-8 rounded-full bg-[#117A65] flex items-center justify-center text-white text-xs font-bold font-mono">
              PP
            </div>
            <div className="overflow-hidden">
              <p className="text-xs font-bold text-white truncate leading-tight">Pengurus Pusat</p>
              <p className="text-[10px] text-gray-500 truncate mt-0.5">{email}</p>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-red-950/40 hover:bg-red-900/40 border border-red-900/30 text-red-300 rounded-lg text-xs font-semibold transition cursor-pointer"
          >
            <LogOut size={14} />
            <span>Keluar Konsol</span>
          </button>
        </div>
      </aside>

      {/* MAIN DASHBOARD CONTENT (RIGHT) */}
      <main className="flex-1 flex flex-col overflow-y-auto h-screen relative">
        {/* Top Header info bar */}
        <header className="bg-white border-b border-gray-200 px-8 py-4 shrink-0 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="font-sans font-bold text-xl text-gray-900 leading-tight capitalize">
              {activeTab === 'overview'
                ? 'Ringkasan Dashboard'
                : activeTab === 'news'
                ? 'Pengelolaan Berita Daerah'
                : activeTab === 'portfolio'
                ? 'Pengelolaan Program Kerja'
                : activeTab === 'structure'
                ? 'Pengurus Bagan Organisasi'
                : 'Pusat Aspirasi & Pesan'}
            </h1>
            <p className="text-xs text-gray-500 mt-0.5">
              Selamat datang kembali, pengendali data portal HPPMI Maros.
            </p>
          </div>

          <button
            onClick={() => {
              onRefreshData();
              showFeedback('success', 'Basis data disinkronisasikan!');
            }}
            className="p-2 border border-gray-200 hover:bg-gray-50 text-gray-600 rounded-lg transition self-start sm:self-center flex items-center space-x-1.5 text-xs font-bold cursor-pointer"
          >
            <RefreshCw size={14} />
            <span>Sinkronisasi Data</span>
          </button>
        </header>

        {/* FEEDBACK STATUS TOAST */}
        <AnimatePresence>
          {feedback && (
            <motion.div
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-6 left-1/2 transform -translate-x-1/2 z-50 max-w-md w-full px-4"
            >
              <div
                className={`p-4 rounded-xl shadow-lg border text-sm font-semibold flex items-center space-x-2.5 ${
                  feedback.type === 'success'
                    ? 'bg-emerald-50 border-emerald-100 text-emerald-800'
                    : 'bg-red-50 border-red-100 text-red-800'
                }`}
              >
                <Check size={18} className="shrink-0" />
                <span>{feedback.text}</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* CORE SCROLLABLE WORKSPACE */}
        <div className="p-8 flex-1 space-y-8">
          
          {/* ======================= TAB 1: OVERVIEW RINGKASAN ======================= */}
          {activeTab === 'overview' && (
            <div className="space-y-8">
              {/* Stats Counters */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  { label: 'Total Berita Rilis', value: stats.totalNews, icon: Newspaper, color: 'text-emerald-600 bg-emerald-50' },
                  { label: 'Program Terdaftar', value: stats.totalPrograms, icon: Award, color: 'text-amber-500 bg-amber-50' },
                  { label: 'Anggota Struktur', value: stats.totalMembers, icon: Users, color: 'text-blue-600 bg-blue-50' },
                  { label: 'Pesan Publik', value: stats.totalMessages, icon: Mail, color: 'text-purple-600 bg-purple-50' }
                ].map((stat) => {
                  const Icon = stat.icon;
                  return (
                    <div key={stat.label} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 flex items-center justify-between">
                      <div className="space-y-1.5">
                        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{stat.label}</p>
                        <h3 className="font-sans font-extrabold text-2xl text-gray-900 leading-none">{stat.value}</h3>
                      </div>
                      <div className={`p-3.5 rounded-xl ${stat.color}`}>
                        <Icon size={24} />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Grid split panels */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Recent unread messages */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 space-y-4 flex flex-col justify-between">
                  <div className="space-y-3">
                    <h3 className="font-bold text-sm text-gray-900 uppercase tracking-wide border-b border-gray-100 pb-2">
                      Pesan Masuk Belum Terbaca ({messages.filter(m => m.status === 'unread').length})
                    </h3>
                    <div className="space-y-3">
                      {messages.filter(m => m.status === 'unread').length > 0 ? (
                        messages.filter(m => m.status === 'unread').slice(0, 3).map((msg) => (
                          <div
                            key={msg.id}
                            onClick={() => {
                              setActiveTab('messages');
                              handleReadMessage(msg);
                            }}
                            className="p-3 bg-amber-50/50 hover:bg-amber-50 border border-amber-100/50 rounded-lg cursor-pointer transition flex items-start space-x-3"
                          >
                            <Mail size={16} className="text-amber-500 shrink-0 mt-0.5" />
                            <div className="space-y-0.5 overflow-hidden">
                              <h4 className="font-bold text-xs text-gray-900 truncate">{msg.subject}</h4>
                              <p className="text-[10px] text-gray-500 truncate leading-relaxed">Dari: {msg.name} ({msg.email})</p>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-xs text-gray-400 italic py-6 text-center">Seluruh pesan masuk telah dibaca.</p>
                      )}
                    </div>
                  </div>
                  {messages.filter(m => m.status === 'unread').length > 0 && (
                    <button
                      onClick={() => setActiveTab('messages')}
                      className="text-xs font-bold text-[#117A65] hover:text-[#0B5345] inline-flex items-center space-x-1 self-start"
                    >
                      <span>Masuk ke Kotak Masuk</span>
                      <ExternalLink size={12} />
                    </button>
                  )}
                </div>

                {/* System Diagnostics logs */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 space-y-4">
                  <h3 className="font-bold text-sm text-gray-900 uppercase tracking-wide border-b border-gray-100 pb-2">
                    Laporan Sistem Konsol
                  </h3>
                  <div className="space-y-3.5 text-xs text-gray-600 font-mono">
                    <div className="flex items-start space-x-2">
                      <span className="text-[#117A65] font-bold">[OK]</span>
                      <p>Koneksi file-database `db.json` berhasil dimuat.</p>
                    </div>
                    <div className="flex items-start space-x-2">
                      <span className="text-[#117A65] font-bold">[OK]</span>
                      <p>Sesi aktif dikomparasikan dengan hash aman.</p>
                    </div>
                    <div className="flex items-start space-x-2">
                      <span className="text-[#117A65] font-bold">[INFO]</span>
                      <p>Kapasitas upload file dioptimalkan hingga 50MB (Base64).</p>
                    </div>
                    <div className="flex items-start space-x-2">
                      <span className="text-amber-500 font-bold">[DIAG]</span>
                      <p>Penyimpanan: internal filesystem persistent container.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ======================= TAB 2: NEWS MANAGER (CRUD) ======================= */}
          {activeTab === 'news' && (
            <div className="space-y-6">
              <AnimatePresence mode="wait">
                {newsForm.showForm ? (
                  /* Create/Edit Form */
                  <motion.div
                    initial={{ opacity: 0, y: -15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15 }}
                    className="bg-white rounded-xl border border-gray-200 p-6 sm:p-8 shadow-sm space-y-6"
                  >
                    <div className="flex justify-between items-center border-b border-gray-100 pb-4">
                      <h3 className="font-bold text-base text-gray-900 uppercase tracking-wide">
                        {newsForm.id ? 'Edit Berita Pengurus' : 'Tulis Berita Baru'}
                      </h3>
                      <button
                        type="button"
                        onClick={() => setNewsForm((prev) => ({ ...prev, showForm: false }))}
                        className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-400 hover:text-gray-600 transition"
                      >
                        <X size={18} />
                      </button>
                    </div>

                    <form onSubmit={handleSaveNews} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {/* Title */}
                        <div className="md:col-span-2 space-y-2">
                          <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Judul Berita</label>
                          <input
                            type="text"
                            value={newsForm.title}
                            onChange={(e) => setNewsForm((prev) => ({ ...prev, title: e.target.value }))}
                            placeholder="Contoh: PP HPPMI Gelar Sosialisasi Bahaya Narkotika"
                            className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:border-[#117A65]"
                            required
                          />
                        </div>

                        {/* Category */}
                        <div className="space-y-2">
                          <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Kategori</label>
                          <select
                            value={newsForm.category}
                            onChange={(e) => setNewsForm((prev) => ({ ...prev, category: e.target.value as any }))}
                            className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:border-[#117A65] bg-white text-gray-800 font-semibold"
                          >
                            <option value="internal HPPMI">Internal HPPMI</option>
                            <option value="Pendidikan">Pendidikan</option>
                            <option value="Sosial">Sosial</option>
                            <option value="Opini">Opini</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {/* Author */}
                        <div className="space-y-2">
                          <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Penulis / Sumber</label>
                          <input
                            type="text"
                            value={newsForm.author}
                            onChange={(e) => setNewsForm((prev) => ({ ...prev, author: e.target.value }))}
                            placeholder="Contoh: Humas PP HPPMI"
                            className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none"
                            required
                          />
                        </div>

                        {/* Tags */}
                        <div className="md:col-span-2 space-y-2">
                          <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Tags (Pisahkan dengan koma)</label>
                          <input
                            type="text"
                            value={newsForm.tagsInput}
                            onChange={(e) => setNewsForm((prev) => ({ ...prev, tagsInput: e.target.value }))}
                            placeholder="Kaderisasi, Pelatihan, Maros"
                            className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none"
                          />
                        </div>
                      </div>

                      {/* Cover Photo Select */}
                      <div className="space-y-3 bg-gray-50 rounded-xl p-5 border border-gray-100">
                        <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide block">Cover Thumbnail Berita</label>
                        
                        {/* Choose stock image or Upload */}
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                          <div className="flex flex-wrap gap-2">
                            {PHOTO_PRESETS.news.map((preset) => (
                              <button
                                key={preset.label}
                                type="button"
                                onClick={() => setNewsForm((prev) => ({ ...prev, thumbnail: preset.url }))}
                                className={`px-2.5 py-1 rounded border text-[11px] font-semibold transition ${
                                  newsForm.thumbnail === preset.url
                                    ? 'bg-[#117A65] border-[#117A65] text-white shadow-sm'
                                    : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-100'
                                }`}
                              >
                                {preset.label}
                              </button>
                            ))}
                          </div>

                          <label className="shrink-0 flex items-center space-x-1 bg-white hover:bg-gray-100 border border-gray-200 text-gray-700 px-3 py-1.5 rounded text-xs font-bold shadow-sm cursor-pointer transition">
                            <Upload size={13} />
                            <span>Unggah Foto Sendiri</span>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={(e) => handleImageUpload(e, 'news')}
                              className="hidden"
                            />
                          </label>
                        </div>

                        {/* Preview and raw input link */}
                        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 pt-3 items-center">
                          <div className="md:col-span-3 space-y-1.5">
                            <span className="text-[10px] text-gray-400 font-mono block">Atau tempelkan tautan URL foto kustom:</span>
                            <input
                              type="text"
                              value={newsForm.thumbnail}
                              onChange={(e) => setNewsForm((prev) => ({ ...prev, thumbnail: e.target.value }))}
                              placeholder="https://..."
                              className="w-full px-3 py-1.5 rounded border border-gray-200 text-xs focus:outline-none"
                            />
                          </div>
                          <div className="md:col-span-2 aspect-video bg-gray-100 rounded-lg overflow-hidden border border-gray-200 flex items-center justify-center">
                            {newsForm.thumbnail ? (
                              <img src={newsForm.thumbnail} alt="Preview Thumbnail" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            ) : (
                              <span className="text-[10px] text-gray-400">Tidak ada foto</span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Custom RichTextEditor */}
                      <div className="space-y-2">
                        <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Isi Konten Berita</label>
                        <RichTextEditor
                          value={newsForm.content}
                          onChange={(val) => setNewsForm((prev) => ({ ...prev, content: val }))}
                        />
                      </div>

                      {/* Actions */}
                      <div className="flex items-center justify-end space-x-3 border-t border-gray-100 pt-5">
                        <button
                          type="button"
                          onClick={() => setNewsForm((prev) => ({ ...prev, showForm: false }))}
                          className="px-5 py-2.5 border border-gray-200 text-gray-600 hover:bg-gray-100 rounded-lg text-xs font-bold transition"
                        >
                          Batal
                        </button>
                        <button
                          type="submit"
                          disabled={loading}
                          className="px-5 py-2.5 bg-[#0B5345] hover:bg-[#117A65] text-white rounded-lg text-xs font-bold shadow transition disabled:opacity-50 flex items-center space-x-1.5 cursor-pointer"
                        >
                          {loading ? (
                            <span className="w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin"></span>
                          ) : (
                            <>
                              <Check size={14} />
                              <span>{newsForm.id ? 'Perbarui Berita' : 'Terbitkan Berita'}</span>
                            </>
                          )}
                        </button>
                      </div>
                    </form>
                  </motion.div>
                ) : (
                  /* News list table */
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      {/* Search box */}
                      <div className="relative max-w-sm w-full">
                        <input
                          type="text"
                          placeholder="Cari berita..."
                          value={newsSearch}
                          onChange={(e) => setNewsSearch(e.target.value)}
                          className="w-full pl-9 pr-4 py-2 rounded-lg border border-gray-200 text-xs bg-white focus:outline-none"
                        />
                        <Search size={14} className="absolute left-3.5 top-3 text-gray-400" />
                      </div>

                      {/* Add button */}
                      <button
                        onClick={() =>
                          setNewsForm({
                            id: '',
                            title: '',
                            category: 'internal HPPMI',
                            content: '',
                            author: 'Humas PP HPPMI',
                            tagsInput: '',
                            thumbnail: PHOTO_PRESETS.news[0].url,
                            showForm: true
                          })
                        }
                        className="px-4 py-2 bg-[#0B5345] hover:bg-[#117A65] text-white text-xs font-bold rounded-lg shadow flex items-center justify-center space-x-1.5 transition shrink-0 cursor-pointer"
                      >
                        <Plus size={14} />
                        <span>Tulis Berita Baru</span>
                      </button>
                    </div>

                    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse text-xs">
                          <thead>
                            <tr className="bg-gray-50 border-b border-gray-200 text-gray-500 font-bold uppercase tracking-wider">
                              <th className="p-4">Berita</th>
                              <th className="p-4">Kategori</th>
                              <th className="p-4">Penulis</th>
                              <th className="p-4">Tanggal Rilis</th>
                              <th className="p-4 text-center">Views</th>
                              <th className="p-4 text-right">Aksi</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-100 text-gray-700">
                            {filteredNews.length > 0 ? (
                              filteredNews.map((art) => (
                                <tr key={art.id} className="hover:bg-gray-50/50 transition">
                                  <td className="p-4 max-w-sm">
                                    <div className="flex items-center space-x-3">
                                      <img src={art.thumbnail} alt="" className="w-10 h-7 rounded object-cover shrink-0 bg-gray-100" referrerPolicy="no-referrer" />
                                      <div className="overflow-hidden">
                                        <h4 className="font-bold text-gray-900 truncate leading-tight">{art.title}</h4>
                                        <span className="text-[10px] text-gray-400 truncate block mt-0.5">slug: {art.slug}</span>
                                      </div>
                                    </div>
                                  </td>
                                  <td className="p-4">
                                    <span className="bg-[#E8F8F5] text-[#0B5345] font-semibold px-2.5 py-0.5 rounded-full text-[10px] uppercase">
                                      {art.category}
                                    </span>
                                  </td>
                                  <td className="p-4 font-semibold text-gray-900">{art.author}</td>
                                  <td className="p-4 text-gray-500 font-mono">
                                    {new Date(art.publishedAt).toLocaleDateString('id-ID', {
                                      day: 'numeric',
                                      month: 'short',
                                      year: 'numeric'
                                    })}
                                  </td>
                                  <td className="p-4 text-center font-bold font-mono">{art.views || 0}</td>
                                  <td className="p-4 text-right space-x-1.5 shrink-0">
                                    <button
                                      onClick={() =>
                                        setNewsForm({
                                          id: art.id,
                                          title: art.title,
                                          category: art.category,
                                          content: art.content,
                                          author: art.author,
                                          tagsInput: art.tags ? art.tags.join(', ') : '',
                                          thumbnail: art.thumbnail,
                                          showForm: true
                                        })
                                      }
                                      className="p-1.5 hover:bg-emerald-50 text-[#117A65] hover:text-[#0B5345] rounded transition"
                                      title="Edit Berita"
                                    >
                                      <Edit2 size={13} />
                                    </button>
                                    <button
                                      onClick={() => handleDeleteNews(art.id)}
                                      className="p-1.5 hover:bg-red-50 text-red-500 hover:text-red-700 rounded transition"
                                      title="Hapus Berita"
                                    >
                                      <Trash2 size={13} />
                                    </button>
                                  </td>
                                </tr>
                              ))
                            ) : (
                              <tr>
                                <td colSpan={6} className="p-8 text-center text-gray-400 italic">
                                  Belum ada berita terdaftar dalam kriteria pencarian ini.
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}

          {/* ======================= TAB 3: PORTFOLIO CRUD ======================= */}
          {activeTab === 'portfolio' && (
            <div className="space-y-6">
              <AnimatePresence mode="wait">
                {progForm.showForm ? (
                  /* Program Form */
                  <motion.div
                    initial={{ opacity: 0, y: -15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15 }}
                    className="bg-white rounded-xl border border-gray-200 p-6 sm:p-8 shadow-sm space-y-6"
                  >
                    <div className="flex justify-between items-center border-b border-gray-100 pb-4">
                      <h3 className="font-bold text-base text-gray-900 uppercase tracking-wide">
                        {progForm.id ? 'Edit Program Kerja' : 'Tambah Program Kerja Baru'}
                      </h3>
                      <button
                        type="button"
                        onClick={() => setProgForm((prev) => ({ ...prev, showForm: false }))}
                        className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-400 hover:text-gray-600 transition"
                      >
                        <X size={18} />
                      </button>
                    </div>

                    <form onSubmit={handleSaveProgram} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {/* Title */}
                        <div className="md:col-span-2 space-y-2">
                          <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Judul Program Kerja</label>
                          <input
                            type="text"
                            value={progForm.title}
                            onChange={(e) => setProgForm((prev) => ({ ...prev, title: e.target.value }))}
                            placeholder="Contoh: HPPMI Maros Mengabdi 2026"
                            className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none"
                            required
                          />
                        </div>

                        {/* Category */}
                        <div className="space-y-2">
                          <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Status / Kategori</label>
                          <select
                            value={progForm.category}
                            onChange={(e) => setProgForm((prev) => ({ ...prev, category: e.target.value as any }))}
                            className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none bg-white font-semibold text-gray-800"
                          >
                            <option value="Past">Selesai (Past)</option>
                            <option value="Ongoing">Sedang Berjalan (Ongoing)</option>
                            <option value="Upcoming">Rencana Kerja (Upcoming)</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Target date */}
                        <div className="space-y-2">
                          <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Jadwal Pelaksanaan</label>
                          <input
                            type="text"
                            value={progForm.targetDate}
                            onChange={(e) => setProgForm((prev) => ({ ...prev, targetDate: e.target.value }))}
                            placeholder="Contoh: Juni - Juli 2026 / Agustus 2026"
                            className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none"
                            required
                          />
                        </div>

                        {/* Participants metric */}
                        <div className="space-y-2">
                          <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Keterlibatan / Peserta</label>
                          <input
                            type="text"
                            value={progForm.participants}
                            onChange={(e) => setProgForm((prev) => ({ ...prev, participants: e.target.value }))}
                            placeholder="Contoh: 120+ Mahasiswa / Lintas Cabang"
                            className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none"
                          />
                        </div>
                      </div>

                      {/* Photo Url */}
                      <div className="space-y-3 bg-gray-50 rounded-xl p-5 border border-gray-100">
                        <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide block">Foto Banner Kegiatan</label>
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                          <span className="text-[10px] text-gray-500">Pilih dari preset stock, kustom URL, atau unggah lokal:</span>
                          <label className="shrink-0 flex items-center space-x-1 bg-white hover:bg-gray-100 border border-gray-200 text-gray-700 px-3 py-1.5 rounded text-xs font-bold shadow-sm cursor-pointer transition">
                            <Upload size={13} />
                            <span>Unggah Banner</span>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={(e) => handleImageUpload(e, 'prog')}
                              className="hidden"
                            />
                          </label>
                        </div>
                        <input
                          type="text"
                          value={progForm.imageUrl}
                          onChange={(e) => setProgForm((prev) => ({ ...prev, imageUrl: e.target.value }))}
                          placeholder="https://..."
                          className="w-full px-3 py-1.5 rounded border border-gray-200 text-xs focus:outline-none"
                        />
                        <div className="aspect-video max-w-sm bg-gray-100 rounded-lg overflow-hidden border border-gray-200">
                          <img src={progForm.imageUrl} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        </div>
                      </div>

                      {/* Description */}
                      <div className="space-y-2">
                        <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Uraian / Deskripsi Program Kerja</label>
                        <textarea
                          value={progForm.description}
                          onChange={(e) => setProgForm((prev) => ({ ...prev, description: e.target.value }))}
                          placeholder="Terangkan secara terperinci latar belakang, sasaran, serta dampak kegiatan..."
                          rows={4}
                          className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none resize-none"
                          required
                        />
                      </div>

                      {/* Actions */}
                      <div className="flex items-center justify-end space-x-3 border-t border-gray-100 pt-5">
                        <button
                          type="button"
                          onClick={() => setProgForm((prev) => ({ ...prev, showForm: false }))}
                          className="px-5 py-2.5 border border-gray-200 text-gray-600 hover:bg-gray-100 rounded-lg text-xs font-bold transition"
                        >
                          Batal
                        </button>
                        <button
                          type="submit"
                          disabled={loading}
                          className="px-5 py-2.5 bg-[#0B5345] hover:bg-[#117A65] text-white rounded-lg text-xs font-bold shadow transition cursor-pointer"
                        >
                          {loading ? 'Menyimpan...' : progForm.id ? 'Perbarui Program' : 'Tambah Program'}
                        </button>
                      </div>
                    </form>
                  </motion.div>
                ) : (
                  /* Program list table */
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="space-y-4"
                  >
                    <div className="flex justify-end">
                      <button
                        onClick={() =>
                          setProgForm({
                            id: '',
                            title: '',
                            description: '',
                            category: 'Ongoing',
                            targetDate: '',
                            participants: '',
                            imageUrl: PHOTO_PRESETS.news[2].url,
                            showForm: true
                          })
                        }
                        className="px-4 py-2 bg-[#0B5345] hover:bg-[#117A65] text-white text-xs font-bold rounded-lg shadow flex items-center justify-center space-x-1.5 transition cursor-pointer"
                      >
                        <Plus size={14} />
                        <span>Tambah Program Kerja</span>
                      </button>
                    </div>

                    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse text-xs">
                          <thead>
                            <tr className="bg-gray-50 border-b border-gray-200 text-gray-500 font-bold uppercase tracking-wider">
                              <th className="p-4">Program Kerja</th>
                              <th className="p-4">Status</th>
                              <th className="p-4">Jadwal</th>
                              <th className="p-4">Keterlibatan</th>
                              <th className="p-4 text-right">Aksi</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-100 text-gray-700">
                            {portfolio.map((prog) => (
                              <tr key={prog.id} className="hover:bg-gray-50/50 transition">
                                <td className="p-4 max-w-xs font-bold text-gray-900 leading-snug">
                                  {prog.title}
                                </td>
                                <td className="p-4">
                                  <span
                                    className={`font-mono text-[9px] font-bold tracking-widest uppercase px-2.5 py-0.5 rounded-full ${
                                      prog.category === 'Past'
                                        ? 'bg-gray-100 text-gray-600'
                                        : prog.category === 'Ongoing'
                                        ? 'bg-emerald-100 text-emerald-800'
                                        : 'bg-amber-100 text-[#0B5345]'
                                    }`}
                                  >
                                    {prog.category === 'Past' ? 'Selesai' : prog.category === 'Ongoing' ? 'Sedang Berjalan' : 'Rencana'}
                                  </span>
                                </td>
                                <td className="p-4 font-semibold text-gray-500">{prog.targetDate}</td>
                                <td className="p-4 font-mono font-bold text-gray-700">{prog.participants || '-'}</td>
                                <td className="p-4 text-right space-x-1.5">
                                  <button
                                    onClick={() =>
                                      setProgForm({
                                        id: prog.id,
                                        title: prog.title,
                                        description: prog.description,
                                        category: prog.category,
                                        targetDate: prog.targetDate,
                                        participants: prog.participants || '',
                                        imageUrl: prog.imageUrl,
                                        showForm: true
                                      })
                                    }
                                    className="p-1.5 hover:bg-emerald-50 text-[#117A65] hover:text-[#0B5345] rounded transition"
                                  >
                                    <Edit2 size={13} />
                                  </button>
                                  <button
                                    onClick={() => handleDeleteProgram(prog.id)}
                                    className="p-1.5 hover:bg-red-50 text-red-500 hover:text-red-700 rounded transition"
                                  >
                                    <Trash2 size={13} />
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}

          {/* ======================= TAB 4: STRUCTURE MEMBERS ======================= */}
          {activeTab === 'structure' && (
            <div className="space-y-6">
              <AnimatePresence mode="wait">
                {memberForm.showForm ? (
                  /* Member Form */
                  <motion.div
                    initial={{ opacity: 0, y: -15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15 }}
                    className="bg-white rounded-xl border border-gray-200 p-6 sm:p-8 shadow-sm space-y-6"
                  >
                    <div className="flex justify-between items-center border-b border-gray-100 pb-4">
                      <h3 className="font-bold text-base text-gray-900 uppercase tracking-wide">
                        {memberForm.id ? 'Edit Profil Anggota' : 'Tambah Profil Anggota Baru'}
                      </h3>
                      <button
                        type="button"
                        onClick={() => setMemberForm((prev) => ({ ...prev, showForm: false }))}
                        className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-400 hover:text-gray-600 transition"
                      >
                        <X size={18} />
                      </button>
                    </div>

                    <form onSubmit={handleSaveMember} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Name */}
                        <div className="space-y-2">
                          <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Nama Lengkap & Gelar</label>
                          <input
                            type="text"
                            value={memberForm.name}
                            onChange={(e) => setMemberForm((prev) => ({ ...prev, name: e.target.value }))}
                            placeholder="Contoh: Muh. Alamsyah, S.IP."
                            className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none"
                            required
                          />
                        </div>

                        {/* Role */}
                        <div className="space-y-2">
                          <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Jabatan / Peran</label>
                          <input
                            type="text"
                            value={memberForm.role}
                            onChange={(e) => setMemberForm((prev) => ({ ...prev, role: e.target.value }))}
                            placeholder="Contoh: Ketua Umum PP HPPMI"
                            className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none"
                            required
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Department selection */}
                        <div className="space-y-2">
                          <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Departemen / Bidang</label>
                          <select
                            value={memberForm.department}
                            onChange={(e) => setMemberForm((prev) => ({ ...prev, department: e.target.value }))}
                            className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none bg-white font-semibold text-gray-800"
                          >
                            <option value="BPH">BPH (Badan Pengurus Harian)</option>
                            <option value="Kaderisasi">Departemen Kaderisasi</option>
                            <option value="Humas">Departemen Hubungan Masyarakat</option>
                            <option value="Pendidikan">Departemen Pendidikan & Iptek</option>
                          </select>
                        </div>

                        {/* Rendering order */}
                        <div className="space-y-2">
                          <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Indeks Urut (Urutan Bagan)</label>
                          <input
                            type="number"
                            value={memberForm.order}
                            onChange={(e) => setMemberForm((prev) => ({ ...prev, order: Number(e.target.value) }))}
                            placeholder="1"
                            className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none"
                            required
                          />
                        </div>
                      </div>

                      {/* Photo url choose */}
                      <div className="space-y-3 bg-gray-50 rounded-xl p-5 border border-gray-100">
                        <label className="text-xs font-extrabold text-gray-700 uppercase tracking-wide block">Pas Foto Anggota</label>
                        <div className="flex flex-wrap gap-2 mb-3">
                          {PHOTO_PRESETS.members.map((preset, idx) => (
                            <button
                              key={preset.label}
                              type="button"
                              onClick={() => setMemberForm((prev) => ({ ...prev, photoUrl: preset.url }))}
                              className={`px-2 py-1 rounded border text-[10px] font-semibold transition ${
                                memberForm.photoUrl === preset.url
                                  ? 'bg-[#117A65] border-[#117A65] text-white shadow-sm'
                                  : 'bg-white border-gray-200 text-gray-500 hover:bg-gray-100'
                              }`}
                            >
                              Preset {idx + 1}
                            </button>
                          ))}
                        </div>
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-t border-gray-100 pt-3">
                          <input
                            type="text"
                            value={memberForm.photoUrl}
                            onChange={(e) => setMemberForm((prev) => ({ ...prev, photoUrl: e.target.value }))}
                            placeholder="Tautan foto kustom"
                            className="w-full max-w-md px-3 py-1.5 rounded border border-gray-200 text-xs focus:outline-none"
                          />
                          <label className="shrink-0 flex items-center space-x-1 bg-white hover:bg-gray-100 border border-gray-200 text-gray-700 px-3 py-1.5 rounded text-xs font-bold shadow-sm cursor-pointer transition">
                            <Upload size={13} />
                            <span>Unggah Pas Foto</span>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={(e) => handleImageUpload(e, 'member')}
                              className="hidden"
                            />
                          </label>
                        </div>
                        <div className="w-16 h-16 rounded-full overflow-hidden border border-gray-200 bg-gray-100 mt-2">
                          <img src={memberForm.photoUrl} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center justify-end space-x-3 border-t border-gray-100 pt-5">
                        <button
                          type="button"
                          onClick={() => setMemberForm((prev) => ({ ...prev, showForm: false }))}
                          className="px-5 py-2.5 border border-gray-200 text-gray-600 hover:bg-gray-100 rounded-lg text-xs font-bold transition"
                        >
                          Batal
                        </button>
                        <button
                          type="submit"
                          disabled={loading}
                          className="px-5 py-2.5 bg-[#0B5345] hover:bg-[#117A65] text-white rounded-lg text-xs font-bold shadow transition cursor-pointer"
                        >
                          {loading ? 'Menyimpan...' : memberForm.id ? 'Perbarui Profil' : 'Tambah Profil'}
                        </button>
                      </div>
                    </form>
                  </motion.div>
                ) : (
                  /* Members table list */
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="space-y-4"
                  >
                    <div className="flex justify-end">
                      <button
                        onClick={() =>
                          setMemberForm({
                            id: '',
                            name: '',
                            role: '',
                            department: 'BPH',
                            order: structure.length + 1,
                            photoUrl: PHOTO_PRESETS.members[0].url,
                            showForm: true
                          })
                        }
                        className="px-4 py-2 bg-[#0B5345] hover:bg-[#117A65] text-white text-xs font-bold rounded-lg shadow flex items-center justify-center space-x-1.5 transition cursor-pointer"
                      >
                        <Plus size={14} />
                        <span>Tambah Anggota Baru</span>
                      </button>
                    </div>

                    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse text-xs">
                          <thead>
                            <tr className="bg-gray-50 border-b border-gray-200 text-gray-500 font-bold uppercase tracking-wider">
                              <th className="p-4">Foto & Nama Pengurus</th>
                              <th className="p-4">Jabatan</th>
                              <th className="p-4">Departemen</th>
                              <th className="p-4 text-center">Indeks Urut</th>
                              <th className="p-4 text-right">Aksi</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-100 text-gray-700">
                            {structure.map((member) => (
                              <tr key={member.id} className="hover:bg-gray-50/50 transition">
                                <td className="p-4 font-bold text-gray-900">
                                  <div className="flex items-center space-x-3">
                                    <img src={member.photoUrl} alt="" className="w-8 h-8 rounded-full object-cover shrink-0 bg-gray-100" referrerPolicy="no-referrer" />
                                    <span>{member.name}</span>
                                  </div>
                                </td>
                                <td className="p-4 font-semibold text-gray-700">{member.role}</td>
                                <td className="p-4">
                                  <span className="bg-emerald-50 text-[#0B5345] font-mono font-bold text-[9px] uppercase px-2 py-0.5 rounded-md">
                                    {member.department}
                                  </span>
                                </td>
                                <td className="p-4 text-center font-bold font-mono text-gray-600">{member.order}</td>
                                <td className="p-4 text-right space-x-1.5">
                                  <button
                                    onClick={() =>
                                      setMemberForm({
                                        id: member.id,
                                        name: member.name,
                                        role: member.role,
                                        department: member.department,
                                        order: member.order,
                                        photoUrl: member.photoUrl,
                                        showForm: true
                                      })
                                    }
                                    className="p-1.5 hover:bg-emerald-50 text-[#117A65] hover:text-[#0B5345] rounded transition"
                                  >
                                    <Edit2 size={13} />
                                  </button>
                                  <button
                                    onClick={() => handleDeleteMember(member.id)}
                                    className="p-1.5 hover:bg-red-50 text-red-500 hover:text-red-700 rounded transition"
                                  >
                                    <Trash2 size={13} />
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}

          {/* ======================= TAB 5: MESSAGE INBOX CENTER ======================= */}
          {activeTab === 'messages' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Message List (LEFT) */}
              <div className="lg:col-span-5 space-y-4">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Saring pengirim, permohonan..."
                    value={msgSearch}
                    onChange={(e) => setMsgSearch(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 rounded-lg border border-gray-200 text-xs bg-white focus:outline-none focus:border-[#117A65]"
                  />
                  <Search size={14} className="absolute left-3 top-2.5 text-gray-400" />
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-200 divide-y divide-gray-100 overflow-hidden">
                  {filteredMessages.length > 0 ? (
                    filteredMessages.map((msg) => (
                      <div
                        key={msg.id}
                        onClick={() => handleReadMessage(msg)}
                        className={`p-4 cursor-pointer transition flex items-start space-x-3 text-xs leading-relaxed ${
                          viewingMessage?.id === msg.id
                            ? 'bg-[#E8F8F5]/80'
                            : msg.status === 'unread'
                            ? 'bg-amber-50/40 hover:bg-amber-50/60 font-semibold'
                            : 'hover:bg-gray-50'
                        }`}
                      >
                        <Mail
                          size={15}
                          className={`shrink-0 mt-0.5 ${
                            msg.status === 'unread' ? 'text-amber-500 fill-amber-500/20' : 'text-gray-400'
                          }`}
                        />
                        <div className="space-y-0.5 flex-1 overflow-hidden">
                          <div className="flex items-center justify-between">
                            <h4 className="font-bold text-gray-900 truncate pr-2">{msg.name}</h4>
                            <span className="text-[10px] font-mono text-gray-400">
                              {new Date(msg.receivedAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}
                            </span>
                          </div>
                          <p className="text-gray-900 font-medium truncate">{msg.subject}</p>
                          <p className="text-gray-500 line-clamp-1 mt-0.5">{msg.message}</p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-center italic py-12 text-gray-400 text-xs">Tidak ada pesan masuk.</p>
                  )}
                </div>
              </div>

              {/* Message Details (RIGHT) */}
              <div className="lg:col-span-7">
                {viewingMessage ? (
                  <motion.div
                    key={viewingMessage.id}
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 sm:p-8 space-y-6"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-100 pb-4">
                      <div className="space-y-1">
                        <span className="font-mono text-[10px] font-bold text-[#117A65] bg-[#E8F8F5] px-2.5 py-0.5 rounded-full uppercase">
                          Aspirasi Publik
                        </span>
                        <h4 className="font-extrabold text-sm sm:text-base text-gray-900 leading-snug">{viewingMessage.subject}</h4>
                      </div>
                      
                      <button
                        onClick={() => handleDeleteMessage(viewingMessage.id)}
                        className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-600 rounded text-xs font-bold transition flex items-center space-x-1 cursor-pointer"
                        title="Hapus Pesan"
                      >
                        <Trash2 size={13} />
                        <span>Hapus</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-gray-600 bg-gray-50/50 rounded-xl p-4 border border-gray-100/50">
                      <div>
                        <p className="font-semibold text-gray-400 uppercase tracking-wide text-[9px]">Pengirim / Nama</p>
                        <p className="font-bold text-gray-900 mt-0.5">{viewingMessage.name}</p>
                      </div>
                      <div>
                        <p className="font-semibold text-gray-400 uppercase tracking-wide text-[9px]">Surat Elektronik (Email)</p>
                        <a href={`mailto:${viewingMessage.email}`} className="font-bold text-[#117A65] hover:underline mt-0.5 block">
                          {viewingMessage.email}
                        </a>
                      </div>
                      <div className="sm:col-span-2 border-t border-gray-100 pt-2 mt-2">
                        <p className="font-semibold text-gray-400 uppercase tracking-wide text-[9px]">Waktu Pengiriman</p>
                        <p className="font-medium text-gray-800 font-mono mt-0.5">
                          {new Date(viewingMessage.receivedAt).toLocaleDateString('id-ID', {
                            weekday: 'long',
                            day: 'numeric',
                            month: 'long',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })} WITA
                        </p>
                      </div>
                    </div>

                    <div className="space-y-2 pt-2">
                      <p className="font-semibold text-gray-400 uppercase tracking-wide text-[9px]">Pernyataan Aspirasi / Pesan:</p>
                      <div className="bg-gray-50 border border-gray-100 rounded-xl p-5 text-sm text-gray-800 leading-relaxed italic whitespace-pre-wrap">
                        \"{viewingMessage.message}\"
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  <div className="border-2 border-dashed border-gray-200 rounded-xl p-16 text-center text-gray-400 text-sm italic">
                    Pilih salah satu pesan masuk di sebelah kiri untuk meninjau detail aspirasi secara lengkap.
                  </div>
                )}
              </div>

            </div>
          )}

        </div>
      </main>
    </div>
  );
}
