/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BookOpen, Target, Shield, Users, Layers, Calendar, UserCheck, Award } from 'lucide-react';
import { OrgMember, PortfolioItem } from '../types.ts';

interface AboutPortfolioProps {
  structure: OrgMember[];
  portfolio: PortfolioItem[];
}

export default function AboutPortfolio({ structure, portfolio }: AboutPortfolioProps) {
  const [activeDepartment, setActiveDepartment] = useState<string>('All');
  const [activeProgramFilter, setActiveProgramFilter] = useState<'All' | 'Past' | 'Ongoing' | 'Upcoming'>('All');

  // List of unique departments for filtering
  const departmentsList = ['All', 'BPH', 'Kaderisasi', 'Humas', 'Pendidikan'];

  // Filtered structure members
  const filteredStructure = structure.filter(
    (member) => activeDepartment === 'All' || member.department.toLowerCase() === activeDepartment.toLowerCase()
  );

  // Filtered programs
  const filteredPrograms = portfolio.filter(
    (prog) => activeProgramFilter === 'All' || prog.category === activeProgramFilter
  );

  return (
    <div className="bg-[#F4F7F6] min-h-screen">
      {/* HEADER HERO */}
      <section className="bg-[#0B5345] text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px]"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-emerald-500/20 via-transparent to-transparent opacity-30"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4 relative z-10">
          <span className="text-amber-400 font-mono text-xs tracking-widest uppercase font-bold">
            Organisasi & Portofolio Kerja
          </span>
          <h1 className="font-display font-bold text-3xl sm:text-5xl">Tentang HPPMI Maros</h1>
          <p className="text-gray-300 text-sm sm:text-base max-w-2xl mx-auto leading-relaxed">
            Menyelami jati diri, struktur kepengurusan, serta program pengabdian tak terhingga demi mewujudkan kemajuan pemuda dan pelajar Maros.
          </p>
        </div>
      </section>

      {/* 1. SEJARAH, VISI & MISI */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          
          {/* History */}
          <div className="space-y-6">
            <div className="inline-flex items-center space-x-2 text-[#117A65] font-mono text-xs tracking-widest uppercase font-bold">
              <BookOpen size={16} />
              <span>Sejarah Perjuangan</span>
            </div>
            <h2 className="font-display font-bold text-2xl sm:text-3xl text-gray-900 leading-tight">
              Butta Salewangang: Tempat Lahir Intelektual HPPMI Maros
            </h2>
            <div className="text-gray-600 text-sm sm:text-base leading-relaxed space-y-4">
              <p>
                Himpunan Pemuda Pelajar Mahasiswa Indonesia Maros (HPPMI Maros) lahir dari rasa tanggung jawab mendalam sekelompok pemuda dan akademisi asal Maros yang menginginkan adanya suatu wadah perjuangan kolektif. Didirikan di tengah dinamika pembangunan Sulawesi Selatan, HPPMI Maros hadir sebagai jembatan persaudaraan yang menghimpun potensi pemuda di perantauan maupun di daerah asal.
              </p>
              <p>
                Dari generasi ke generasi, HPPMI Maros mengawal nilai kepeloporan, keagamaan, dan kemasyarakatan. Melalui pembinaan kader yang terstruktur, organisasi ini telah menelurkan ribuan alumni yang kini berkiprah di sektor publik, swasta, akademisi, hingga kepemimpinan politik di tingkat lokal maupun nasional.
              </p>
              <p>
                Kini, dengan semangat kolaboratif yang adaptif terhadap era digital, PP HPPMI Maros memantapkan langkah sebagai lokomotif kemajuan pemuda yang berintegritas tinggi.
              </p>
            </div>
          </div>

          {/* Vision & Mission */}
          <div className="bg-white border border-emerald-950/5 rounded-2xl shadow-md p-8 sm:p-10 space-y-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-3 text-[#117A65]">
                <Target size={22} className="shrink-0" />
                <h3 className="font-display font-bold text-xl text-gray-900">Visi Organisasi</h3>
              </div>
              <p className="text-gray-600 text-sm sm:text-base leading-relaxed italic border-l-4 border-amber-400 pl-4 bg-amber-50/50 py-3.5 rounded-r-lg">
                "Terwujudnya HPPMI Maros sebagai organisasi kepemudaan yang edukatif, mandiri, dan berkarakter kepemimpinan luhur guna mengawal kemaslahatan masyarakat Kabupaten Maros."
              </p>
            </div>

            <div className="space-y-4">
              <div className="flex items-center space-x-3 text-[#117A65]">
                <Shield size={22} className="shrink-0" />
                <h3 className="font-display font-bold text-xl text-gray-900">Misi Perjuangan</h3>
              </div>
              <ul className="space-y-3.5 text-gray-600 text-sm sm:text-base">
                {[
                  'Menyelenggarakan sistem pengaderan yang intensif, ilmiah, dan berlandaskan nilai-nilai ketakwaan.',
                  'Mempererat tali silaturahmi dan solidaritas seluruh kader, pelajar, dan alumni lintas komisariat.',
                  'Menjadi mitra strategis sekaligus kritis bagi Pemerintah Daerah Kabupaten Maros dalam memformulasikan kebijakan kepemudaan dan kesejahteraan masyarakat.',
                  'Menyelenggarakan bakti sosial serta pendampingan literasi di desa-desa binaan secara berkala.',
                ].map((item, idx) => (
                  <li key={idx} className="flex items-start space-x-3">
                    <span className="flex items-center justify-center bg-[#E8F8F5] text-[#117A65] font-bold text-xs rounded-full w-5 h-5 shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span className="leading-relaxed">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

        </div>
      </section>

      {/* 2. INTERACTIVE ORGANIZATIONAL CHART */}
      <section className="bg-emerald-950 text-white py-20 border-y border-emerald-900/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          {/* Header */}
          <div className="text-center space-y-3 max-w-2xl mx-auto">
            <span className="text-amber-400 font-mono text-xs tracking-widest uppercase font-bold">
              Kepengurusan Aktif
            </span>
            <h2 className="font-display font-bold text-2xl sm:text-4xl">Struktur Organisasi</h2>
            <p className="text-emerald-200/80 text-sm">
              Sinergi jajaran Badan Pengurus Harian (BPH) dan Ketua Departemen Pengurus Pusat HPPMI Maros Periode Bakti berjalan.
            </p>
          </div>

          {/* Department Filter Selector */}
          <div className="flex flex-wrap items-center justify-center gap-2">
            {departmentsList.map((dept) => (
              <button
                key={dept}
                onClick={() => setActiveDepartment(dept)}
                className={`px-4 py-1.5 rounded-lg text-xs font-display font-semibold uppercase tracking-wider transition-all duration-200 cursor-pointer ${
                  activeDepartment === dept
                    ? 'bg-amber-400 text-emerald-950 shadow-md'
                    : 'bg-emerald-900/60 text-emerald-100 hover:bg-emerald-900'
                }`}
              >
                {dept === 'All' ? 'Semua Bidang' : dept}
              </button>
            ))}
          </div>

          {/* Hierarchical Visual rendering */}
          {activeDepartment === 'All' ? (
            <div className="space-y-12">
              {/* LEVEL 1: KETUA UMUM */}
              <div className="flex justify-center">
                {structure.filter(m => m.role.toLowerCase().includes('ketua umum')).map(ketum => (
                  <motion.div
                    key={ketum.id}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-[#0B5345] border-2 border-amber-400 rounded-2xl p-5 text-center shadow-lg w-72 space-y-3 relative overflow-hidden"
                  >
                    <div className="absolute top-0 inset-x-0 h-1.5 bg-amber-400" />
                    <img
                      src={ketum.photoUrl}
                      alt={ketum.name}
                      className="w-24 h-24 rounded-full mx-auto object-cover border-2 border-amber-400"
                    />
                    <div>
                      <h4 className="font-bold text-base text-white">{ketum.name}</h4>
                      <p className="text-xs text-amber-300 font-mono uppercase tracking-wider font-semibold mt-1">
                        {ketum.role}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* LEVEL 2: SEKJEN & BENDUM */}
              <div className="flex flex-wrap justify-center gap-8">
                {structure.filter(m => m.role.toLowerCase().includes('sekretaris jenderal') || m.role.toLowerCase().includes('bendahara umum')).map(bph => (
                  <motion.div
                    key={bph.id}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-[#0B5345] border border-emerald-700 rounded-xl p-4 text-center shadow-md w-64 space-y-3"
                  >
                    <img
                      src={bph.photoUrl}
                      alt={bph.name}
                      className="w-20 h-20 rounded-full mx-auto object-cover border-2 border-emerald-600"
                    />
                    <div>
                      <h4 className="font-bold text-sm text-white">{bph.name}</h4>
                      <p className="text-[11px] text-emerald-300 font-mono uppercase tracking-wider font-semibold mt-1">
                        {bph.role}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* LEVEL 3: DEPARTEMENT HEADS */}
              <div className="border-t border-emerald-900/60 pt-8">
                <p className="text-center text-xs font-mono uppercase text-emerald-300 tracking-widest mb-6">
                  Jajaran Dewan Pengurus Departemen
                </p>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {structure.filter(m => !m.role.toLowerCase().includes('ketua umum') && !m.role.toLowerCase().includes('sekretaris jenderal') && !m.role.toLowerCase().includes('bendahara umum')).map(dept => (
                    <motion.div
                      key={dept.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="bg-emerald-900/30 border border-emerald-900/50 rounded-xl p-4 text-center space-y-3"
                    >
                      <img
                        src={dept.photoUrl}
                        alt={dept.name}
                        className="w-16 h-16 rounded-full mx-auto object-cover border-2 border-emerald-800"
                      />
                      <div>
                        <h5 className="font-semibold text-xs text-white leading-tight">{dept.name}</h5>
                        <p className="text-[10px] text-emerald-400 font-mono uppercase mt-1">
                          {dept.role}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* Selected Department Grid */
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
              <AnimatePresence mode="popLayout">
                {filteredStructure.map((member) => (
                  <motion.div
                    key={member.id}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ duration: 0.3 }}
                    className="bg-[#0B5345] border border-emerald-800 rounded-xl p-4 text-center space-y-3 shadow"
                  >
                    <img
                      src={member.photoUrl}
                      alt={member.name}
                      className="w-20 h-20 rounded-full mx-auto object-cover border-2 border-emerald-600"
                    />
                    <div>
                      <h4 className="font-bold text-sm text-white">{member.name}</h4>
                      <p className="text-[11px] text-amber-300 font-mono uppercase tracking-wider font-semibold mt-1">
                        {member.role}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}

        </div>
      </section>

      {/* 3. FILTERABLE PORTFOLIO / WORK PROGRAMS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div className="space-y-2">
            <span className="text-[#117A65] font-mono text-xs tracking-widest uppercase font-bold">
              Kinerja Nyata
            </span>
            <h2 className="font-display font-bold text-2xl sm:text-4xl text-gray-900">
              Portofolio & Program Kerja
            </h2>
          </div>

          {/* Program Filters */}
          <div className="flex items-center bg-gray-200/60 p-0.5 rounded-lg text-xs mt-4 md:mt-0 max-w-max self-start md:self-end border border-gray-200">
            {[
              { label: 'Semua', value: 'All' },
              { label: 'Selesai', value: 'Past' },
              { label: 'Berjalan', value: 'Ongoing' },
              { label: 'Rencana', value: 'Upcoming' },
            ].map((btn) => (
              <button
                key={btn.value}
                onClick={() => setActiveProgramFilter(btn.value as any)}
                className={`px-3 py-1.5 rounded-md font-semibold transition cursor-pointer ${
                  activeProgramFilter === btn.value
                    ? 'bg-white shadow-sm text-[#0B5345]'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                {btn.label}
              </button>
            ))}
          </div>
        </div>

        {/* Portfolio Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence mode="popLayout">
            {filteredPrograms.length > 0 ? (
              filteredPrograms.map((prog, idx) => (
                <motion.div
                  key={prog.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.4 }}
                  className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-100 flex flex-col justify-between hover:shadow-lg transition-shadow"
                >
                  <div>
                    {/* Program Banner */}
                    <div className="relative aspect-video bg-gray-100 overflow-hidden shrink-0">
                      <img
                        src={prog.imageUrl}
                        alt={prog.title}
                        loading="lazy"
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      {/* Status badge */}
                      <span
                        className={`absolute top-3 left-3 font-mono text-[9px] font-bold tracking-widest uppercase px-2.5 py-1 rounded-full shadow-sm ${
                          prog.category === 'Past'
                            ? 'bg-gray-100 text-gray-700 border border-gray-200'
                            : prog.category === 'Ongoing'
                            ? 'bg-emerald-500 text-white'
                            : 'bg-amber-400 text-[#0B5345]'
                        }`}
                      >
                        {prog.category === 'Past'
                          ? 'Selesai'
                          : prog.category === 'Ongoing'
                          ? 'Sedang Berjalan'
                          : 'Rencana'}
                      </span>
                    </div>

                    {/* Program Content */}
                    <div className="p-6 space-y-3">
                      <div className="flex items-center space-x-1.5 text-xs text-[#117A65] font-semibold font-mono uppercase">
                        <Calendar size={13} />
                        <span>{prog.targetDate}</span>
                      </div>
                      <h3 className="font-display font-bold text-lg text-gray-900 leading-snug">
                        {prog.title}
                      </h3>
                      <p className="text-sm text-gray-600 leading-relaxed line-clamp-3">
                        {prog.description}
                      </p>
                    </div>
                  </div>

                  {/* Program Footer metrics */}
                  {prog.participants && (
                    <div className="p-6 pt-0 border-t-0 bg-gray-50/50 py-3.5 px-6 flex items-center justify-between text-xs text-gray-500 font-medium border-t border-gray-100/50">
                      <span className="flex items-center space-x-1">
                        <Users size={13} className="text-[#117A65]" />
                        <span>Keterlibatan:</span>
                      </span>
                      <span className="font-bold text-gray-700">{prog.participants}</span>
                    </div>
                  )}
                </motion.div>
              ))
            ) : (
              <div className="col-span-3 text-center py-16 bg-white rounded-xl border border-dashed border-gray-200">
                <Award size={36} className="mx-auto text-gray-300 mb-3" />
                <p className="text-gray-500 text-sm">Tidak ada program kerja dalam kriteria ini.</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </section>
    </div>
  );
}
