/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Calendar, Eye, ArrowRight, BookOpen, ChevronLeft, ChevronRight, Hash } from 'lucide-react';
import { NewsArticle } from '../types.ts';

interface NewsPortalProps {
  news: NewsArticle[];
  onNavigate: (page: string, params?: any) => void;
}

export default function NewsPortal({ news, onNavigate }: NewsPortalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // 1. Categories listing with dynamic counts
  const categoriesWithCounts = useMemo(() => {
    const counts: Record<string, number> = { All: news.length };
    news.forEach((item) => {
      counts[item.category] = (counts[item.category] || 0) + 1;
    });
    return counts;
  }, [news]);

  // 2. Filtered News Articles list
  const filteredNews = useMemo(() => {
    return news.filter((item) => {
      const matchesSearch =
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;

      return matchesSearch && matchesCategory;
    });
  }, [news, searchQuery, selectedCategory]);

  // 3. Trending Articles (sorted by views descending)
  const trendingArticles = useMemo(() => {
    return [...news].sort((a, b) => (b.views || 0) - (a.views || 0)).slice(0, 4);
  }, [news]);

  // 4. Pagination math
  const totalPages = Math.ceil(filteredNews.length / itemsPerPage);
  const paginatedNews = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredNews.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredNews, currentPage]);

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
      window.scrollTo({ top: 200, behavior: 'smooth' });
    }
  };

  const handleCategorySelect = (cat: string) => {
    setSelectedCategory(cat);
    setCurrentPage(1);
  };

  return (
    <div className="bg-[#F4F7F6] min-h-screen">
      {/* HERO HEADER */}
      <section className="bg-[#0B5345] text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px]"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-emerald-500/20 via-transparent to-transparent opacity-30"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4 relative z-10">
          <span className="text-amber-400 font-mono text-xs tracking-widest uppercase font-bold">
            Kabar Butta Salewangang
          </span>
          <h1 className="font-display font-bold text-3xl sm:text-5xl">Portal Berita HPPMI</h1>
          <p className="text-gray-300 text-sm sm:text-base max-w-2xl mx-auto leading-relaxed">
            Menyajikan berita resmi seputar organisasi, info beasiswa kuliah, aksi pengabdian masyarakat, serta opini kritis kader muda Maros.
          </p>
        </div>
      </section>

      {/* PORTAL MAIN CONTENT AREA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* MAIN ARTICLES COLUMN (LEFT) */}
          <div className="lg:col-span-8 space-y-8">
            <div className="flex items-center justify-between border-b border-gray-200 pb-4">
              <h2 className="font-display font-bold text-lg sm:text-xl text-gray-900 uppercase tracking-wider">
                {selectedCategory === 'All' ? 'Seluruh Kabar Berita' : `Kategori: ${selectedCategory}`}
              </h2>
              <span className="text-xs text-gray-500 font-mono">
                Menampilkan {filteredNews.length} Artikel
              </span>
            </div>

            <AnimatePresence mode="popLayout">
              {paginatedNews.length > 0 ? (
                paginatedNews.map((article) => (
                  <motion.article
                    key={article.id}
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.3 }}
                    className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden flex flex-col md:flex-row hover:shadow-md transition duration-200"
                  >
                    {/* Article image */}
                    <div className="md:w-2/5 relative h-48 md:h-auto overflow-hidden bg-gray-100 shrink-0">
                      <img
                        src={article.thumbnail}
                        alt={article.title}
                        loading="lazy"
                        className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                      <span className="absolute top-3 left-3 bg-[#0B5345] text-amber-400 font-mono text-[9px] font-bold tracking-widest px-2.5 py-1 rounded-full uppercase shadow-sm">
                        {article.category}
                      </span>
                    </div>

                    {/* Article metadata and text */}
                    <div className="p-6 md:w-3/5 flex flex-col justify-between space-y-4">
                      <div className="space-y-2">
                        <div className="flex items-center space-x-4 text-xs text-gray-500 font-medium">
                          <span className="flex items-center space-x-1">
                            <Calendar size={13} />
                            <span>
                              {new Date(article.publishedAt).toLocaleDateString('id-ID', {
                                day: 'numeric',
                                month: 'short',
                                year: 'numeric',
                              })}
                            </span>
                          </span>
                          <span className="flex items-center space-x-1">
                            <Eye size={13} />
                            <span>{article.views || 0} Kali dibaca</span>
                          </span>
                        </div>

                        <h3
                          onClick={() => onNavigate('news-detail', article.slug)}
                          className="font-display font-bold text-base sm:text-xl text-gray-900 leading-snug line-clamp-2 hover:text-[#117A65] transition-colors cursor-pointer"
                        >
                          {article.title}
                        </h3>

                        {/* Summary Excerpt */}
                        <div
                          className="text-gray-600 text-sm line-clamp-3 leading-relaxed"
                          dangerouslySetInnerHTML={{
                            __html: article.content.replace(/<[^>]*>/g, '').substring(0, 140) + '...',
                          }}
                        />
                      </div>

                      <div className="flex items-center justify-between pt-4 border-t border-gray-100 text-xs">
                        <span className="text-gray-500">
                          Oleh: <span className="font-semibold text-gray-700">{article.author}</span>
                        </span>
                        <button
                          onClick={() => onNavigate('news-detail', article.slug)}
                          className="font-bold text-[#117A65] hover:text-[#0B5345] flex items-center space-x-1 group cursor-pointer"
                        >
                          <span>Baca Selengkapnya</span>
                          <ArrowRight size={14} className="transform group-hover:translate-x-0.5 transition-transform" />
                        </button>
                      </div>
                    </div>
                  </motion.article>
                ))
              ) : (
                <div className="text-center py-20 bg-white rounded-xl border border-dashed border-gray-200">
                  <BookOpen size={40} className="mx-auto text-gray-300 mb-3" />
                  <p className="text-gray-500 text-sm">Tidak menemukan berita yang cocok dengan kriteria Anda.</p>
                </div>
              )}
            </AnimatePresence>

            {/* PAGINATION WRAPPER */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center space-x-1.5 pt-8">
                <button
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                  className="p-2 border border-gray-200 rounded-lg bg-white text-gray-600 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition cursor-pointer"
                >
                  <ChevronLeft size={16} />
                </button>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                  <button
                    key={page}
                    onClick={() => handlePageChange(page)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                      currentPage === page
                        ? 'bg-[#0B5345] text-white shadow-sm'
                        : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    {page}
                  </button>
                ))}
                <button
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                  className="p-2 border border-gray-200 rounded-lg bg-white text-gray-600 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition cursor-pointer"
                >
                  <ChevronRight size={16} />
                </button>
              </div>
            )}
          </div>

          {/* SIDEBAR COLUMNS (RIGHT) */}
          <div className="lg:col-span-4 space-y-8">
            
            {/* 1. SEARCH WIDGET */}
            <div className="bg-white rounded-xl border border-emerald-950/5 shadow-sm p-6 space-y-4">
              <h4 className="font-display font-bold text-sm text-gray-900 uppercase tracking-wider border-l-4 border-[#117A65] pl-3">
                Pencarian Berita
              </h4>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Cari berita, tag, penulis..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-gray-200 focus:outline-none focus:border-[#117A65] text-sm text-gray-700 bg-gray-50/50"
                />
                <Search size={16} className="absolute left-3.5 top-3.5 text-gray-400" />
              </div>
            </div>

            {/* 2. CATEGORIES FILTER LIST */}
            <div className="bg-white rounded-xl border border-emerald-950/5 shadow-sm p-6 space-y-4">
              <h4 className="font-display font-bold text-sm text-gray-900 uppercase tracking-wider border-l-4 border-[#117A65] pl-3">
                Kategori Berita
              </h4>
              <div className="flex flex-col space-y-1">
                {Object.keys(categoriesWithCounts).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => handleCategorySelect(cat)}
                    className={`flex items-center justify-between px-3 py-2 rounded-lg text-sm transition text-left cursor-pointer ${
                      selectedCategory === cat
                        ? 'bg-[#E8F8F5] text-[#0B5345] font-semibold'
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                    }`}
                  >
                    <span>{cat === 'All' ? 'Semua Kategori' : cat}</span>
                    <span className="text-xs font-mono bg-gray-200/50 px-2.5 py-0.5 rounded-full font-bold text-gray-600">
                      {categoriesWithCounts[cat]}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* 3. TRENDING/POPULAR POSTS */}
            <div className="bg-white rounded-xl border border-emerald-950/5 shadow-sm p-6 space-y-5">
              <h4 className="font-display font-bold text-sm text-gray-900 uppercase tracking-wider border-l-4 border-[#117A65] pl-3">
                Kabar Paling Populer
              </h4>
              <div className="space-y-4">
                {trendingArticles.map((article, idx) => (
                  <div
                    key={article.id}
                    onClick={() => onNavigate('news-detail', article.slug)}
                    className="flex items-start space-x-3 cursor-pointer group pb-3 border-b border-gray-100 last:border-0 last:pb-0"
                  >
                    {/* Trending Number counter block */}
                    <span className="font-display font-bold text-2xl text-[#117A65]/35 group-hover:text-[#117A65] transition w-8 shrink-0 pt-1">
                      0{idx + 1}
                    </span>
                    <div className="space-y-1 flex-1">
                      <h5 className="font-bold text-xs sm:text-sm text-gray-800 leading-snug line-clamp-2 group-hover:text-[#117A65] transition">
                        {article.title}
                      </h5>
                      <span className="flex items-center space-x-1.5 text-[10px] text-gray-400 font-mono">
                        <Eye size={10} />
                        <span>{article.views || 0} views</span>
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 4. INSTANT TAGS CLOUD */}
            <div className="bg-white rounded-xl border border-emerald-950/5 shadow-sm p-6 space-y-4">
              <h4 className="font-display font-bold text-sm text-gray-900 uppercase tracking-wider border-l-4 border-[#117A65] pl-3">
                Hashtag Terkait
              </h4>
              <div className="flex flex-wrap gap-1.5">
                {['LK II', 'Beasiswa', 'Rammang-Rammang', 'Pendidikan', 'Bakti Sosial', 'Kader', 'Maros'].map((tag) => (
                  <button
                    key={tag}
                    onClick={() => {
                      setSearchQuery(tag);
                      setCurrentPage(1);
                    }}
                    className="inline-flex items-center space-x-1 bg-gray-100 hover:bg-emerald-50 hover:text-[#0B5345] border border-gray-200 hover:border-emerald-200 text-xs text-gray-600 px-2.5 py-1 rounded-md transition cursor-pointer"
                  >
                    <Hash size={10} />
                    <span>{tag}</span>
                  </button>
                ))}
              </div>
            </div>

          </div>

        </div>
      </section>
    </div>
  );
}
